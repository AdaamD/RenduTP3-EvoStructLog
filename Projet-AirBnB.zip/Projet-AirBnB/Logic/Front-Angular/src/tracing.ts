import { WebTracerProvider } from '@opentelemetry/sdk-trace-web';
import { BatchSpanProcessor } from '@opentelemetry/sdk-trace-base';
import { registerInstrumentations } from '@opentelemetry/instrumentation';
import { DocumentLoadInstrumentation } from '@opentelemetry/instrumentation-document-load';
import { UserInteractionInstrumentation } from '@opentelemetry/instrumentation-user-interaction';
import { FetchInstrumentation } from '@opentelemetry/instrumentation-fetch';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';

// Configure l'exportateur pour envoyer les traces au backend
const exporter = new OTLPTraceExporter({
  url: 'http://localhost:4318/v1/traces', // Assurez-vous que cette URL correspond à votre backend de traces
});

// Créer et configurer le fournisseur de traces
const provider = new WebTracerProvider();
provider.addSpanProcessor(new BatchSpanProcessor(exporter));
provider.register();

// Enregistrer les instrumentations
registerInstrumentations({
  instrumentations: [
    new DocumentLoadInstrumentation(),
    new UserInteractionInstrumentation(),
    new FetchInstrumentation(),
  ],
});

// Optionnel : définir un nom de service global pour les traces
const tracer = provider.getTracer('mean-frontend'); // Utilisez ce tracer pour créer des spans
