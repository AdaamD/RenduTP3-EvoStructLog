import { Routes } from '@angular/router';
import { AffichageBienComponent } from './affichage-bien/affichage-bien.component';

export const routes: Routes = [

    {
    path: '',
    component:  AffichageBienComponent
    }
        
];
