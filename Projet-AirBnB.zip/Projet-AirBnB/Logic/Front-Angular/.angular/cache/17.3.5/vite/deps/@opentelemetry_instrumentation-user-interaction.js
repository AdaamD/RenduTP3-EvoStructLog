import {
  getElementXPath
} from "./chunk-VCIPMLAT.js";
import "./chunk-YUPDH3JR.js";
import {
  InstrumentationBase,
  isWrapped
} from "./chunk-2S52PPVH.js";
import {
  hrTime
} from "./chunk-FT7YRNA4.js";
import {
  context,
  trace
} from "./chunk-UXK5IXEU.js";
import "./chunk-ASLTLD6L.js";

// node_modules/@opentelemetry/instrumentation-user-interaction/build/esm/enums/AttributeNames.js
var AttributeNames;
(function(AttributeNames2) {
  AttributeNames2["EVENT_TYPE"] = "event_type";
  AttributeNames2["TARGET_ELEMENT"] = "target_element";
  AttributeNames2["TARGET_XPATH"] = "target_xpath";
  AttributeNames2["HTTP_URL"] = "http.url";
})(AttributeNames || (AttributeNames = {}));

// node_modules/@opentelemetry/instrumentation-user-interaction/build/esm/version.js
var PACKAGE_VERSION = "0.41.0";
var PACKAGE_NAME = "@opentelemetry/instrumentation-user-interaction";

// node_modules/@opentelemetry/instrumentation-user-interaction/build/esm/instrumentation.js
var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2)
        if (Object.prototype.hasOwnProperty.call(b2, p))
          d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var ZONE_CONTEXT_KEY = "OT_ZONE_CONTEXT";
var EVENT_NAVIGATION_NAME = "Navigation:";
var DEFAULT_EVENT_NAMES = ["click"];
function defaultShouldPreventSpanCreation() {
  return false;
}
var UserInteractionInstrumentation = (
  /** @class */
  function(_super) {
    __extends(UserInteractionInstrumentation2, _super);
    function UserInteractionInstrumentation2(config) {
      if (config === void 0) {
        config = {};
      }
      var _a;
      var _this = _super.call(this, PACKAGE_NAME, PACKAGE_VERSION, config) || this;
      _this.version = PACKAGE_VERSION;
      _this.moduleName = "user-interaction";
      _this._spansData = /* @__PURE__ */ new WeakMap();
      _this._wrappedListeners = /* @__PURE__ */ new WeakMap();
      _this._eventsSpanMap = /* @__PURE__ */ new WeakMap();
      _this._eventNames = new Set((_a = config === null || config === void 0 ? void 0 : config.eventNames) !== null && _a !== void 0 ? _a : DEFAULT_EVENT_NAMES);
      _this._shouldPreventSpanCreation = typeof (config === null || config === void 0 ? void 0 : config.shouldPreventSpanCreation) === "function" ? config.shouldPreventSpanCreation : defaultShouldPreventSpanCreation;
      return _this;
    }
    UserInteractionInstrumentation2.prototype.init = function() {
    };
    UserInteractionInstrumentation2.prototype._checkForTimeout = function(task, span) {
      var spanData = this._spansData.get(span);
      if (spanData) {
        if (task.source === "setTimeout") {
          spanData.hrTimeLastTimeout = hrTime();
        } else if (task.source !== "Promise.then" && task.source !== "setTimeout") {
          spanData.hrTimeLastTimeout = void 0;
        }
      }
    };
    UserInteractionInstrumentation2.prototype._allowEventName = function(eventName) {
      return this._eventNames.has(eventName);
    };
    UserInteractionInstrumentation2.prototype._createSpan = function(element, eventName, parentSpan) {
      var _a;
      if (!(element instanceof HTMLElement)) {
        return void 0;
      }
      if (!element.getAttribute) {
        return void 0;
      }
      if (element.hasAttribute("disabled")) {
        return void 0;
      }
      if (!this._allowEventName(eventName)) {
        return void 0;
      }
      var xpath = getElementXPath(element, true);
      try {
        var span = this.tracer.startSpan(eventName, {
          attributes: (_a = {}, _a[AttributeNames.EVENT_TYPE] = eventName, _a[AttributeNames.TARGET_ELEMENT] = element.tagName, _a[AttributeNames.TARGET_XPATH] = xpath, _a[AttributeNames.HTTP_URL] = window.location.href, _a)
        }, parentSpan ? trace.setSpan(context.active(), parentSpan) : void 0);
        if (this._shouldPreventSpanCreation(eventName, element, span) === true) {
          return void 0;
        }
        this._spansData.set(span, {
          taskCount: 0
        });
        return span;
      } catch (e) {
        this._diag.error("failed to start create new user interaction span", e);
      }
      return void 0;
    };
    UserInteractionInstrumentation2.prototype._decrementTask = function(span) {
      var spanData = this._spansData.get(span);
      if (spanData) {
        spanData.taskCount--;
        if (spanData.taskCount === 0) {
          this._tryToEndSpan(span, spanData.hrTimeLastTimeout);
        }
      }
    };
    UserInteractionInstrumentation2.prototype._getCurrentSpan = function(zone) {
      var context2 = zone.get(ZONE_CONTEXT_KEY);
      if (context2) {
        return trace.getSpan(context2);
      }
      return context2;
    };
    UserInteractionInstrumentation2.prototype._incrementTask = function(span) {
      var spanData = this._spansData.get(span);
      if (spanData) {
        spanData.taskCount++;
      }
    };
    UserInteractionInstrumentation2.prototype.addPatchedListener = function(on, type, listener, wrappedListener) {
      var listener2Type = this._wrappedListeners.get(listener);
      if (!listener2Type) {
        listener2Type = /* @__PURE__ */ new Map();
        this._wrappedListeners.set(listener, listener2Type);
      }
      var element2patched = listener2Type.get(type);
      if (!element2patched) {
        element2patched = /* @__PURE__ */ new Map();
        listener2Type.set(type, element2patched);
      }
      if (element2patched.has(on)) {
        return false;
      }
      element2patched.set(on, wrappedListener);
      return true;
    };
    UserInteractionInstrumentation2.prototype.removePatchedListener = function(on, type, listener) {
      var listener2Type = this._wrappedListeners.get(listener);
      if (!listener2Type) {
        return void 0;
      }
      var element2patched = listener2Type.get(type);
      if (!element2patched) {
        return void 0;
      }
      var patched = element2patched.get(on);
      if (patched) {
        element2patched.delete(on);
        if (element2patched.size === 0) {
          listener2Type.delete(type);
          if (listener2Type.size === 0) {
            this._wrappedListeners.delete(listener);
          }
        }
      }
      return patched;
    };
    UserInteractionInstrumentation2.prototype._invokeListener = function(listener, target, args) {
      if (typeof listener === "function") {
        return listener.apply(target, args);
      } else {
        return listener.handleEvent(args[0]);
      }
    };
    UserInteractionInstrumentation2.prototype._patchAddEventListener = function() {
      var plugin = this;
      return function(original) {
        return function addEventListenerPatched(type, listener, useCapture) {
          if (!listener) {
            return original.call(this, type, listener, useCapture);
          }
          var once = useCapture && typeof useCapture === "object" && useCapture.once;
          var patchedListener = function() {
            var _this = this;
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
            }
            var parentSpan;
            var event = args[0];
            var target = event === null || event === void 0 ? void 0 : event.target;
            if (event) {
              parentSpan = plugin._eventsSpanMap.get(event);
            }
            if (once) {
              plugin.removePatchedListener(this, type, listener);
            }
            var span = plugin._createSpan(target, type, parentSpan);
            if (span) {
              if (event) {
                plugin._eventsSpanMap.set(event, span);
              }
              return context.with(trace.setSpan(context.active(), span), function() {
                var result = plugin._invokeListener(listener, _this, args);
                span.end();
                return result;
              });
            } else {
              return plugin._invokeListener(listener, this, args);
            }
          };
          if (plugin.addPatchedListener(this, type, listener, patchedListener)) {
            return original.call(this, type, patchedListener, useCapture);
          }
        };
      };
    };
    UserInteractionInstrumentation2.prototype._patchRemoveEventListener = function() {
      var plugin = this;
      return function(original) {
        return function removeEventListenerPatched(type, listener, useCapture) {
          var wrappedListener = plugin.removePatchedListener(this, type, listener);
          if (wrappedListener) {
            return original.call(this, type, wrappedListener, useCapture);
          } else {
            return original.call(this, type, listener, useCapture);
          }
        };
      };
    };
    UserInteractionInstrumentation2.prototype._getPatchableEventTargets = function() {
      return window.EventTarget ? [EventTarget.prototype] : [Node.prototype, Window.prototype];
    };
    UserInteractionInstrumentation2.prototype._patchHistoryApi = function() {
      this._unpatchHistoryApi();
      this._wrap(history, "replaceState", this._patchHistoryMethod());
      this._wrap(history, "pushState", this._patchHistoryMethod());
      this._wrap(history, "back", this._patchHistoryMethod());
      this._wrap(history, "forward", this._patchHistoryMethod());
      this._wrap(history, "go", this._patchHistoryMethod());
    };
    UserInteractionInstrumentation2.prototype._patchHistoryMethod = function() {
      var plugin = this;
      return function(original) {
        return function patchHistoryMethod() {
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }
          var url = "" + location.pathname + location.hash + location.search;
          var result = original.apply(this, args);
          var urlAfter = "" + location.pathname + location.hash + location.search;
          if (url !== urlAfter) {
            plugin._updateInteractionName(urlAfter);
          }
          return result;
        };
      };
    };
    UserInteractionInstrumentation2.prototype._unpatchHistoryApi = function() {
      if (isWrapped(history.replaceState))
        this._unwrap(history, "replaceState");
      if (isWrapped(history.pushState))
        this._unwrap(history, "pushState");
      if (isWrapped(history.back))
        this._unwrap(history, "back");
      if (isWrapped(history.forward))
        this._unwrap(history, "forward");
      if (isWrapped(history.go))
        this._unwrap(history, "go");
    };
    UserInteractionInstrumentation2.prototype._updateInteractionName = function(url) {
      var span = trace.getSpan(context.active());
      if (span && typeof span.updateName === "function") {
        span.updateName(EVENT_NAVIGATION_NAME + " " + url);
      }
    };
    UserInteractionInstrumentation2.prototype._patchZoneCancelTask = function() {
      var plugin = this;
      return function(original) {
        return function patchCancelTask(task) {
          var currentZone = Zone.current;
          var currentSpan = plugin._getCurrentSpan(currentZone);
          if (currentSpan && plugin._shouldCountTask(task, currentZone)) {
            plugin._decrementTask(currentSpan);
          }
          return original.call(this, task);
        };
      };
    };
    UserInteractionInstrumentation2.prototype._patchZoneScheduleTask = function() {
      var plugin = this;
      return function(original) {
        return function patchScheduleTask(task) {
          var currentZone = Zone.current;
          var currentSpan = plugin._getCurrentSpan(currentZone);
          if (currentSpan && plugin._shouldCountTask(task, currentZone)) {
            plugin._incrementTask(currentSpan);
            plugin._checkForTimeout(task, currentSpan);
          }
          return original.call(this, task);
        };
      };
    };
    UserInteractionInstrumentation2.prototype._patchZoneRunTask = function() {
      var plugin = this;
      return function(original) {
        return function patchRunTask(task, applyThis, applyArgs) {
          var event = Array.isArray(applyArgs) && applyArgs[0] instanceof Event ? applyArgs[0] : void 0;
          var target = event === null || event === void 0 ? void 0 : event.target;
          var span;
          var activeZone = this;
          if (target) {
            span = plugin._createSpan(target, task.eventName);
            if (span) {
              plugin._incrementTask(span);
              return activeZone.run(function() {
                try {
                  return context.with(trace.setSpan(context.active(), span), function() {
                    var currentZone = Zone.current;
                    task._zone = currentZone;
                    return original.call(currentZone, task, applyThis, applyArgs);
                  });
                } finally {
                  plugin._decrementTask(span);
                }
              });
            }
          } else {
            span = plugin._getCurrentSpan(activeZone);
          }
          try {
            return original.call(activeZone, task, applyThis, applyArgs);
          } finally {
            if (span && plugin._shouldCountTask(task, activeZone)) {
              plugin._decrementTask(span);
            }
          }
        };
      };
    };
    UserInteractionInstrumentation2.prototype._shouldCountTask = function(task, currentZone) {
      if (task._zone) {
        currentZone = task._zone;
      }
      if (!currentZone || !task.data || task.data.isPeriodic) {
        return false;
      }
      var currentSpan = this._getCurrentSpan(currentZone);
      if (!currentSpan) {
        return false;
      }
      if (!this._spansData.get(currentSpan)) {
        return false;
      }
      return task.type === "macroTask" || task.type === "microTask";
    };
    UserInteractionInstrumentation2.prototype._tryToEndSpan = function(span, endTime) {
      if (span) {
        var spanData = this._spansData.get(span);
        if (spanData) {
          span.end(endTime);
          this._spansData.delete(span);
        }
      }
    };
    UserInteractionInstrumentation2.prototype.enable = function() {
      var _this = this;
      var ZoneWithPrototype = this.getZoneWithPrototype();
      this._diag.debug("applying patch to", this.moduleName, this.version, "zone:", !!ZoneWithPrototype);
      if (ZoneWithPrototype) {
        if (isWrapped(ZoneWithPrototype.prototype.runTask)) {
          this._unwrap(ZoneWithPrototype.prototype, "runTask");
          this._diag.debug("removing previous patch from method runTask");
        }
        if (isWrapped(ZoneWithPrototype.prototype.scheduleTask)) {
          this._unwrap(ZoneWithPrototype.prototype, "scheduleTask");
          this._diag.debug("removing previous patch from method scheduleTask");
        }
        if (isWrapped(ZoneWithPrototype.prototype.cancelTask)) {
          this._unwrap(ZoneWithPrototype.prototype, "cancelTask");
          this._diag.debug("removing previous patch from method cancelTask");
        }
        this._zonePatched = true;
        this._wrap(ZoneWithPrototype.prototype, "runTask", this._patchZoneRunTask());
        this._wrap(ZoneWithPrototype.prototype, "scheduleTask", this._patchZoneScheduleTask());
        this._wrap(ZoneWithPrototype.prototype, "cancelTask", this._patchZoneCancelTask());
      } else {
        this._zonePatched = false;
        var targets = this._getPatchableEventTargets();
        targets.forEach(function(target) {
          if (isWrapped(target.addEventListener)) {
            _this._unwrap(target, "addEventListener");
            _this._diag.debug("removing previous patch from method addEventListener");
          }
          if (isWrapped(target.removeEventListener)) {
            _this._unwrap(target, "removeEventListener");
            _this._diag.debug("removing previous patch from method removeEventListener");
          }
          _this._wrap(target, "addEventListener", _this._patchAddEventListener());
          _this._wrap(target, "removeEventListener", _this._patchRemoveEventListener());
        });
      }
      this._patchHistoryApi();
    };
    UserInteractionInstrumentation2.prototype.disable = function() {
      var _this = this;
      var ZoneWithPrototype = this.getZoneWithPrototype();
      this._diag.debug("removing patch from", this.moduleName, this.version, "zone:", !!ZoneWithPrototype);
      if (ZoneWithPrototype && this._zonePatched) {
        if (isWrapped(ZoneWithPrototype.prototype.runTask)) {
          this._unwrap(ZoneWithPrototype.prototype, "runTask");
        }
        if (isWrapped(ZoneWithPrototype.prototype.scheduleTask)) {
          this._unwrap(ZoneWithPrototype.prototype, "scheduleTask");
        }
        if (isWrapped(ZoneWithPrototype.prototype.cancelTask)) {
          this._unwrap(ZoneWithPrototype.prototype, "cancelTask");
        }
      } else {
        var targets = this._getPatchableEventTargets();
        targets.forEach(function(target) {
          if (isWrapped(target.addEventListener)) {
            _this._unwrap(target, "addEventListener");
          }
          if (isWrapped(target.removeEventListener)) {
            _this._unwrap(target, "removeEventListener");
          }
        });
      }
      this._unpatchHistoryApi();
    };
    UserInteractionInstrumentation2.prototype.getZoneWithPrototype = function() {
      var _window = window;
      return _window.Zone;
    };
    return UserInteractionInstrumentation2;
  }(InstrumentationBase)
);
export {
  AttributeNames,
  UserInteractionInstrumentation
};
//# sourceMappingURL=@opentelemetry_instrumentation-user-interaction.js.map
