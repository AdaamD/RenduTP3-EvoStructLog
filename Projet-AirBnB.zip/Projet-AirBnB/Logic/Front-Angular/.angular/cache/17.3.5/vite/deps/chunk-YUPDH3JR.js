import {
  BindOnceFuture,
  CompositePropagator,
  DEFAULT_ATTRIBUTE_COUNT_LIMIT,
  DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT,
  ExportResultCode,
  Resource,
  SEMATTRS_EXCEPTION_MESSAGE,
  SEMATTRS_EXCEPTION_STACKTRACE,
  SEMATTRS_EXCEPTION_TYPE,
  TracesSamplerValues,
  W3CBaggagePropagator,
  W3CTraceContextPropagator,
  addHrTimes,
  getEnv,
  getEnvWithoutDefaults,
  getTimeOrigin,
  globalErrorHandler,
  hrTime,
  hrTimeDuration,
  hrTimeToMicroseconds,
  internal,
  isAttributeValue,
  isTimeInput,
  isTimeInputHrTime,
  isTracingSuppressed,
  merge,
  millisToHrTime,
  otperformance,
  sanitizeAttributes,
  suppressTracing,
  unrefTimer
} from "./chunk-FT7YRNA4.js";
import {
  INVALID_SPAN_CONTEXT,
  SamplingDecision,
  SpanKind,
  SpanStatusCode,
  TraceFlags,
  context,
  diag,
  isSpanContextValid,
  isValidTraceId,
  propagation,
  trace
} from "./chunk-UXK5IXEU.js";

// node_modules/@opentelemetry/sdk-trace-base/build/esm/enums.js
var ExceptionEventName = "exception";

// node_modules/@opentelemetry/sdk-trace-base/build/esm/Span.js
var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __values = function(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m)
    return m.call(o);
  if (o && typeof o.length === "number")
    return {
      next: function() {
        if (o && i >= o.length)
          o = void 0;
        return { value: o && o[i++], done: !o };
      }
    };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2)
    for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar)
          ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var Span = (
  /** @class */
  function() {
    function Span2(parentTracer, context2, spanName, spanContext, kind, parentSpanId, links, startTime, _deprecatedClock, attributes) {
      if (links === void 0) {
        links = [];
      }
      this.attributes = {};
      this.links = [];
      this.events = [];
      this._droppedAttributesCount = 0;
      this._droppedEventsCount = 0;
      this._droppedLinksCount = 0;
      this.status = {
        code: SpanStatusCode.UNSET
      };
      this.endTime = [0, 0];
      this._ended = false;
      this._duration = [-1, -1];
      this.name = spanName;
      this._spanContext = spanContext;
      this.parentSpanId = parentSpanId;
      this.kind = kind;
      this.links = links;
      var now = Date.now();
      this._performanceStartTime = otperformance.now();
      this._performanceOffset = now - (this._performanceStartTime + getTimeOrigin());
      this._startTimeProvided = startTime != null;
      this.startTime = this._getTime(startTime !== null && startTime !== void 0 ? startTime : now);
      this.resource = parentTracer.resource;
      this.instrumentationLibrary = parentTracer.instrumentationLibrary;
      this._spanLimits = parentTracer.getSpanLimits();
      this._attributeValueLengthLimit = this._spanLimits.attributeValueLengthLimit || 0;
      if (attributes != null) {
        this.setAttributes(attributes);
      }
      this._spanProcessor = parentTracer.getActiveSpanProcessor();
      this._spanProcessor.onStart(this, context2);
    }
    Span2.prototype.spanContext = function() {
      return this._spanContext;
    };
    Span2.prototype.setAttribute = function(key, value) {
      if (value == null || this._isSpanEnded())
        return this;
      if (key.length === 0) {
        diag.warn("Invalid attribute key: " + key);
        return this;
      }
      if (!isAttributeValue(value)) {
        diag.warn("Invalid attribute value set for key: " + key);
        return this;
      }
      if (Object.keys(this.attributes).length >= this._spanLimits.attributeCountLimit && !Object.prototype.hasOwnProperty.call(this.attributes, key)) {
        this._droppedAttributesCount++;
        return this;
      }
      this.attributes[key] = this._truncateToSize(value);
      return this;
    };
    Span2.prototype.setAttributes = function(attributes) {
      var e_1, _a;
      try {
        for (var _b = __values(Object.entries(attributes)), _c = _b.next(); !_c.done; _c = _b.next()) {
          var _d = __read(_c.value, 2), k = _d[0], v = _d[1];
          this.setAttribute(k, v);
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return this;
    };
    Span2.prototype.addEvent = function(name, attributesOrStartTime, timeStamp) {
      if (this._isSpanEnded())
        return this;
      if (this._spanLimits.eventCountLimit === 0) {
        diag.warn("No events allowed.");
        this._droppedEventsCount++;
        return this;
      }
      if (this.events.length >= this._spanLimits.eventCountLimit) {
        if (this._droppedEventsCount === 0) {
          diag.debug("Dropping extra events.");
        }
        this.events.shift();
        this._droppedEventsCount++;
      }
      if (isTimeInput(attributesOrStartTime)) {
        if (!isTimeInput(timeStamp)) {
          timeStamp = attributesOrStartTime;
        }
        attributesOrStartTime = void 0;
      }
      var attributes = sanitizeAttributes(attributesOrStartTime);
      this.events.push({
        name,
        attributes,
        time: this._getTime(timeStamp),
        droppedAttributesCount: 0
      });
      return this;
    };
    Span2.prototype.addLink = function(link) {
      this.links.push(link);
      return this;
    };
    Span2.prototype.addLinks = function(links) {
      var _a;
      (_a = this.links).push.apply(_a, __spreadArray([], __read(links), false));
      return this;
    };
    Span2.prototype.setStatus = function(status) {
      if (this._isSpanEnded())
        return this;
      this.status = __assign({}, status);
      if (this.status.message != null && typeof status.message !== "string") {
        diag.warn("Dropping invalid status.message of type '" + typeof status.message + "', expected 'string'");
        delete this.status.message;
      }
      return this;
    };
    Span2.prototype.updateName = function(name) {
      if (this._isSpanEnded())
        return this;
      this.name = name;
      return this;
    };
    Span2.prototype.end = function(endTime) {
      if (this._isSpanEnded()) {
        diag.error(this.name + " " + this._spanContext.traceId + "-" + this._spanContext.spanId + " - You can only call end() on a span once.");
        return;
      }
      this._ended = true;
      this.endTime = this._getTime(endTime);
      this._duration = hrTimeDuration(this.startTime, this.endTime);
      if (this._duration[0] < 0) {
        diag.warn("Inconsistent start and end time, startTime > endTime. Setting span duration to 0ms.", this.startTime, this.endTime);
        this.endTime = this.startTime.slice();
        this._duration = [0, 0];
      }
      if (this._droppedEventsCount > 0) {
        diag.warn("Dropped " + this._droppedEventsCount + " events because eventCountLimit reached");
      }
      this._spanProcessor.onEnd(this);
    };
    Span2.prototype._getTime = function(inp) {
      if (typeof inp === "number" && inp < otperformance.now()) {
        return hrTime(inp + this._performanceOffset);
      }
      if (typeof inp === "number") {
        return millisToHrTime(inp);
      }
      if (inp instanceof Date) {
        return millisToHrTime(inp.getTime());
      }
      if (isTimeInputHrTime(inp)) {
        return inp;
      }
      if (this._startTimeProvided) {
        return millisToHrTime(Date.now());
      }
      var msDuration = otperformance.now() - this._performanceStartTime;
      return addHrTimes(this.startTime, millisToHrTime(msDuration));
    };
    Span2.prototype.isRecording = function() {
      return this._ended === false;
    };
    Span2.prototype.recordException = function(exception, time) {
      var attributes = {};
      if (typeof exception === "string") {
        attributes[SEMATTRS_EXCEPTION_MESSAGE] = exception;
      } else if (exception) {
        if (exception.code) {
          attributes[SEMATTRS_EXCEPTION_TYPE] = exception.code.toString();
        } else if (exception.name) {
          attributes[SEMATTRS_EXCEPTION_TYPE] = exception.name;
        }
        if (exception.message) {
          attributes[SEMATTRS_EXCEPTION_MESSAGE] = exception.message;
        }
        if (exception.stack) {
          attributes[SEMATTRS_EXCEPTION_STACKTRACE] = exception.stack;
        }
      }
      if (attributes[SEMATTRS_EXCEPTION_TYPE] || attributes[SEMATTRS_EXCEPTION_MESSAGE]) {
        this.addEvent(ExceptionEventName, attributes, time);
      } else {
        diag.warn("Failed to record an exception " + exception);
      }
    };
    Object.defineProperty(Span2.prototype, "duration", {
      get: function() {
        return this._duration;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Span2.prototype, "ended", {
      get: function() {
        return this._ended;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Span2.prototype, "droppedAttributesCount", {
      get: function() {
        return this._droppedAttributesCount;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Span2.prototype, "droppedEventsCount", {
      get: function() {
        return this._droppedEventsCount;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(Span2.prototype, "droppedLinksCount", {
      get: function() {
        return this._droppedLinksCount;
      },
      enumerable: false,
      configurable: true
    });
    Span2.prototype._isSpanEnded = function() {
      if (this._ended) {
        diag.warn("Can not execute the operation on ended Span {traceId: " + this._spanContext.traceId + ", spanId: " + this._spanContext.spanId + "}");
      }
      return this._ended;
    };
    Span2.prototype._truncateToLimitUtil = function(value, limit) {
      if (value.length <= limit) {
        return value;
      }
      return value.substr(0, limit);
    };
    Span2.prototype._truncateToSize = function(value) {
      var _this = this;
      var limit = this._attributeValueLengthLimit;
      if (limit <= 0) {
        diag.warn("Attribute value limit must be positive, got " + limit);
        return value;
      }
      if (typeof value === "string") {
        return this._truncateToLimitUtil(value, limit);
      }
      if (Array.isArray(value)) {
        return value.map(function(val) {
          return typeof val === "string" ? _this._truncateToLimitUtil(val, limit) : val;
        });
      }
      return value;
    };
    return Span2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/Sampler.js
var SamplingDecision2;
(function(SamplingDecision3) {
  SamplingDecision3[SamplingDecision3["NOT_RECORD"] = 0] = "NOT_RECORD";
  SamplingDecision3[SamplingDecision3["RECORD"] = 1] = "RECORD";
  SamplingDecision3[SamplingDecision3["RECORD_AND_SAMPLED"] = 2] = "RECORD_AND_SAMPLED";
})(SamplingDecision2 || (SamplingDecision2 = {}));

// node_modules/@opentelemetry/sdk-trace-base/build/esm/sampler/AlwaysOffSampler.js
var AlwaysOffSampler = (
  /** @class */
  function() {
    function AlwaysOffSampler2() {
    }
    AlwaysOffSampler2.prototype.shouldSample = function() {
      return {
        decision: SamplingDecision2.NOT_RECORD
      };
    };
    AlwaysOffSampler2.prototype.toString = function() {
      return "AlwaysOffSampler";
    };
    return AlwaysOffSampler2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/sampler/AlwaysOnSampler.js
var AlwaysOnSampler = (
  /** @class */
  function() {
    function AlwaysOnSampler2() {
    }
    AlwaysOnSampler2.prototype.shouldSample = function() {
      return {
        decision: SamplingDecision2.RECORD_AND_SAMPLED
      };
    };
    AlwaysOnSampler2.prototype.toString = function() {
      return "AlwaysOnSampler";
    };
    return AlwaysOnSampler2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/sampler/ParentBasedSampler.js
var ParentBasedSampler = (
  /** @class */
  function() {
    function ParentBasedSampler2(config) {
      var _a, _b, _c, _d;
      this._root = config.root;
      if (!this._root) {
        globalErrorHandler(new Error("ParentBasedSampler must have a root sampler configured"));
        this._root = new AlwaysOnSampler();
      }
      this._remoteParentSampled = (_a = config.remoteParentSampled) !== null && _a !== void 0 ? _a : new AlwaysOnSampler();
      this._remoteParentNotSampled = (_b = config.remoteParentNotSampled) !== null && _b !== void 0 ? _b : new AlwaysOffSampler();
      this._localParentSampled = (_c = config.localParentSampled) !== null && _c !== void 0 ? _c : new AlwaysOnSampler();
      this._localParentNotSampled = (_d = config.localParentNotSampled) !== null && _d !== void 0 ? _d : new AlwaysOffSampler();
    }
    ParentBasedSampler2.prototype.shouldSample = function(context2, traceId, spanName, spanKind, attributes, links) {
      var parentContext = trace.getSpanContext(context2);
      if (!parentContext || !isSpanContextValid(parentContext)) {
        return this._root.shouldSample(context2, traceId, spanName, spanKind, attributes, links);
      }
      if (parentContext.isRemote) {
        if (parentContext.traceFlags & TraceFlags.SAMPLED) {
          return this._remoteParentSampled.shouldSample(context2, traceId, spanName, spanKind, attributes, links);
        }
        return this._remoteParentNotSampled.shouldSample(context2, traceId, spanName, spanKind, attributes, links);
      }
      if (parentContext.traceFlags & TraceFlags.SAMPLED) {
        return this._localParentSampled.shouldSample(context2, traceId, spanName, spanKind, attributes, links);
      }
      return this._localParentNotSampled.shouldSample(context2, traceId, spanName, spanKind, attributes, links);
    };
    ParentBasedSampler2.prototype.toString = function() {
      return "ParentBased{root=" + this._root.toString() + ", remoteParentSampled=" + this._remoteParentSampled.toString() + ", remoteParentNotSampled=" + this._remoteParentNotSampled.toString() + ", localParentSampled=" + this._localParentSampled.toString() + ", localParentNotSampled=" + this._localParentNotSampled.toString() + "}";
    };
    return ParentBasedSampler2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/sampler/TraceIdRatioBasedSampler.js
var TraceIdRatioBasedSampler = (
  /** @class */
  function() {
    function TraceIdRatioBasedSampler2(_ratio) {
      if (_ratio === void 0) {
        _ratio = 0;
      }
      this._ratio = _ratio;
      this._ratio = this._normalize(_ratio);
      this._upperBound = Math.floor(this._ratio * 4294967295);
    }
    TraceIdRatioBasedSampler2.prototype.shouldSample = function(context2, traceId) {
      return {
        decision: isValidTraceId(traceId) && this._accumulate(traceId) < this._upperBound ? SamplingDecision2.RECORD_AND_SAMPLED : SamplingDecision2.NOT_RECORD
      };
    };
    TraceIdRatioBasedSampler2.prototype.toString = function() {
      return "TraceIdRatioBased{" + this._ratio + "}";
    };
    TraceIdRatioBasedSampler2.prototype._normalize = function(ratio) {
      if (typeof ratio !== "number" || isNaN(ratio))
        return 0;
      return ratio >= 1 ? 1 : ratio <= 0 ? 0 : ratio;
    };
    TraceIdRatioBasedSampler2.prototype._accumulate = function(traceId) {
      var accumulation = 0;
      for (var i = 0; i < traceId.length / 8; i++) {
        var pos = i * 8;
        var part = parseInt(traceId.slice(pos, pos + 8), 16);
        accumulation = (accumulation ^ part) >>> 0;
      }
      return accumulation;
    };
    return TraceIdRatioBasedSampler2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/config.js
var env = getEnv();
var FALLBACK_OTEL_TRACES_SAMPLER = TracesSamplerValues.AlwaysOn;
var DEFAULT_RATIO = 1;
function loadDefaultConfig() {
  var _env = getEnv();
  return {
    sampler: buildSamplerFromEnv(env),
    forceFlushTimeoutMillis: 3e4,
    generalLimits: {
      attributeValueLengthLimit: _env.OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT,
      attributeCountLimit: _env.OTEL_ATTRIBUTE_COUNT_LIMIT
    },
    spanLimits: {
      attributeValueLengthLimit: _env.OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT,
      attributeCountLimit: _env.OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT,
      linkCountLimit: _env.OTEL_SPAN_LINK_COUNT_LIMIT,
      eventCountLimit: _env.OTEL_SPAN_EVENT_COUNT_LIMIT,
      attributePerEventCountLimit: _env.OTEL_SPAN_ATTRIBUTE_PER_EVENT_COUNT_LIMIT,
      attributePerLinkCountLimit: _env.OTEL_SPAN_ATTRIBUTE_PER_LINK_COUNT_LIMIT
    }
  };
}
function buildSamplerFromEnv(environment) {
  if (environment === void 0) {
    environment = getEnv();
  }
  switch (environment.OTEL_TRACES_SAMPLER) {
    case TracesSamplerValues.AlwaysOn:
      return new AlwaysOnSampler();
    case TracesSamplerValues.AlwaysOff:
      return new AlwaysOffSampler();
    case TracesSamplerValues.ParentBasedAlwaysOn:
      return new ParentBasedSampler({
        root: new AlwaysOnSampler()
      });
    case TracesSamplerValues.ParentBasedAlwaysOff:
      return new ParentBasedSampler({
        root: new AlwaysOffSampler()
      });
    case TracesSamplerValues.TraceIdRatio:
      return new TraceIdRatioBasedSampler(getSamplerProbabilityFromEnv(environment));
    case TracesSamplerValues.ParentBasedTraceIdRatio:
      return new ParentBasedSampler({
        root: new TraceIdRatioBasedSampler(getSamplerProbabilityFromEnv(environment))
      });
    default:
      diag.error('OTEL_TRACES_SAMPLER value "' + environment.OTEL_TRACES_SAMPLER + " invalid, defaulting to " + FALLBACK_OTEL_TRACES_SAMPLER + '".');
      return new AlwaysOnSampler();
  }
}
function getSamplerProbabilityFromEnv(environment) {
  if (environment.OTEL_TRACES_SAMPLER_ARG === void 0 || environment.OTEL_TRACES_SAMPLER_ARG === "") {
    diag.error("OTEL_TRACES_SAMPLER_ARG is blank, defaulting to " + DEFAULT_RATIO + ".");
    return DEFAULT_RATIO;
  }
  var probability = Number(environment.OTEL_TRACES_SAMPLER_ARG);
  if (isNaN(probability)) {
    diag.error("OTEL_TRACES_SAMPLER_ARG=" + environment.OTEL_TRACES_SAMPLER_ARG + " was given, but it is invalid, defaulting to " + DEFAULT_RATIO + ".");
    return DEFAULT_RATIO;
  }
  if (probability < 0 || probability > 1) {
    diag.error("OTEL_TRACES_SAMPLER_ARG=" + environment.OTEL_TRACES_SAMPLER_ARG + " was given, but it is out of range ([0..1]), defaulting to " + DEFAULT_RATIO + ".");
    return DEFAULT_RATIO;
  }
  return probability;
}

// node_modules/@opentelemetry/sdk-trace-base/build/esm/utility.js
function mergeConfig(userConfig) {
  var perInstanceDefaults = {
    sampler: buildSamplerFromEnv()
  };
  var DEFAULT_CONFIG = loadDefaultConfig();
  var target = Object.assign({}, DEFAULT_CONFIG, perInstanceDefaults, userConfig);
  target.generalLimits = Object.assign({}, DEFAULT_CONFIG.generalLimits, userConfig.generalLimits || {});
  target.spanLimits = Object.assign({}, DEFAULT_CONFIG.spanLimits, userConfig.spanLimits || {});
  return target;
}
function reconfigureLimits(userConfig) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
  var spanLimits = Object.assign({}, userConfig.spanLimits);
  var parsedEnvConfig = getEnvWithoutDefaults();
  spanLimits.attributeCountLimit = (_f = (_e = (_d = (_b = (_a = userConfig.spanLimits) === null || _a === void 0 ? void 0 : _a.attributeCountLimit) !== null && _b !== void 0 ? _b : (_c = userConfig.generalLimits) === null || _c === void 0 ? void 0 : _c.attributeCountLimit) !== null && _d !== void 0 ? _d : parsedEnvConfig.OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT) !== null && _e !== void 0 ? _e : parsedEnvConfig.OTEL_ATTRIBUTE_COUNT_LIMIT) !== null && _f !== void 0 ? _f : DEFAULT_ATTRIBUTE_COUNT_LIMIT;
  spanLimits.attributeValueLengthLimit = (_m = (_l = (_k = (_h = (_g = userConfig.spanLimits) === null || _g === void 0 ? void 0 : _g.attributeValueLengthLimit) !== null && _h !== void 0 ? _h : (_j = userConfig.generalLimits) === null || _j === void 0 ? void 0 : _j.attributeValueLengthLimit) !== null && _k !== void 0 ? _k : parsedEnvConfig.OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT) !== null && _l !== void 0 ? _l : parsedEnvConfig.OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT) !== null && _m !== void 0 ? _m : DEFAULT_ATTRIBUTE_VALUE_LENGTH_LIMIT;
  return Object.assign({}, userConfig, { spanLimits });
}

// node_modules/@opentelemetry/sdk-trace-base/build/esm/export/BatchSpanProcessorBase.js
var BatchSpanProcessorBase = (
  /** @class */
  function() {
    function BatchSpanProcessorBase2(_exporter, config) {
      this._exporter = _exporter;
      this._isExporting = false;
      this._finishedSpans = [];
      this._droppedSpansCount = 0;
      var env2 = getEnv();
      this._maxExportBatchSize = typeof (config === null || config === void 0 ? void 0 : config.maxExportBatchSize) === "number" ? config.maxExportBatchSize : env2.OTEL_BSP_MAX_EXPORT_BATCH_SIZE;
      this._maxQueueSize = typeof (config === null || config === void 0 ? void 0 : config.maxQueueSize) === "number" ? config.maxQueueSize : env2.OTEL_BSP_MAX_QUEUE_SIZE;
      this._scheduledDelayMillis = typeof (config === null || config === void 0 ? void 0 : config.scheduledDelayMillis) === "number" ? config.scheduledDelayMillis : env2.OTEL_BSP_SCHEDULE_DELAY;
      this._exportTimeoutMillis = typeof (config === null || config === void 0 ? void 0 : config.exportTimeoutMillis) === "number" ? config.exportTimeoutMillis : env2.OTEL_BSP_EXPORT_TIMEOUT;
      this._shutdownOnce = new BindOnceFuture(this._shutdown, this);
      if (this._maxExportBatchSize > this._maxQueueSize) {
        diag.warn("BatchSpanProcessor: maxExportBatchSize must be smaller or equal to maxQueueSize, setting maxExportBatchSize to match maxQueueSize");
        this._maxExportBatchSize = this._maxQueueSize;
      }
    }
    BatchSpanProcessorBase2.prototype.forceFlush = function() {
      if (this._shutdownOnce.isCalled) {
        return this._shutdownOnce.promise;
      }
      return this._flushAll();
    };
    BatchSpanProcessorBase2.prototype.onStart = function(_span, _parentContext) {
    };
    BatchSpanProcessorBase2.prototype.onEnd = function(span) {
      if (this._shutdownOnce.isCalled) {
        return;
      }
      if ((span.spanContext().traceFlags & TraceFlags.SAMPLED) === 0) {
        return;
      }
      this._addToBuffer(span);
    };
    BatchSpanProcessorBase2.prototype.shutdown = function() {
      return this._shutdownOnce.call();
    };
    BatchSpanProcessorBase2.prototype._shutdown = function() {
      var _this = this;
      return Promise.resolve().then(function() {
        return _this.onShutdown();
      }).then(function() {
        return _this._flushAll();
      }).then(function() {
        return _this._exporter.shutdown();
      });
    };
    BatchSpanProcessorBase2.prototype._addToBuffer = function(span) {
      if (this._finishedSpans.length >= this._maxQueueSize) {
        if (this._droppedSpansCount === 0) {
          diag.debug("maxQueueSize reached, dropping spans");
        }
        this._droppedSpansCount++;
        return;
      }
      if (this._droppedSpansCount > 0) {
        diag.warn("Dropped " + this._droppedSpansCount + " spans because maxQueueSize reached");
        this._droppedSpansCount = 0;
      }
      this._finishedSpans.push(span);
      this._maybeStartTimer();
    };
    BatchSpanProcessorBase2.prototype._flushAll = function() {
      var _this = this;
      return new Promise(function(resolve, reject) {
        var promises = [];
        var count = Math.ceil(_this._finishedSpans.length / _this._maxExportBatchSize);
        for (var i = 0, j = count; i < j; i++) {
          promises.push(_this._flushOneBatch());
        }
        Promise.all(promises).then(function() {
          resolve();
        }).catch(reject);
      });
    };
    BatchSpanProcessorBase2.prototype._flushOneBatch = function() {
      var _this = this;
      this._clearTimer();
      if (this._finishedSpans.length === 0) {
        return Promise.resolve();
      }
      return new Promise(function(resolve, reject) {
        var timer = setTimeout(function() {
          reject(new Error("Timeout"));
        }, _this._exportTimeoutMillis);
        context.with(suppressTracing(context.active()), function() {
          var spans;
          if (_this._finishedSpans.length <= _this._maxExportBatchSize) {
            spans = _this._finishedSpans;
            _this._finishedSpans = [];
          } else {
            spans = _this._finishedSpans.splice(0, _this._maxExportBatchSize);
          }
          var doExport = function() {
            return _this._exporter.export(spans, function(result) {
              var _a;
              clearTimeout(timer);
              if (result.code === ExportResultCode.SUCCESS) {
                resolve();
              } else {
                reject((_a = result.error) !== null && _a !== void 0 ? _a : new Error("BatchSpanProcessor: span export failed"));
              }
            });
          };
          var pendingResources = null;
          for (var i = 0, len = spans.length; i < len; i++) {
            var span = spans[i];
            if (span.resource.asyncAttributesPending && span.resource.waitForAsyncAttributes) {
              pendingResources !== null && pendingResources !== void 0 ? pendingResources : pendingResources = [];
              pendingResources.push(span.resource.waitForAsyncAttributes());
            }
          }
          if (pendingResources === null) {
            doExport();
          } else {
            Promise.all(pendingResources).then(doExport, function(err) {
              globalErrorHandler(err);
              reject(err);
            });
          }
        });
      });
    };
    BatchSpanProcessorBase2.prototype._maybeStartTimer = function() {
      var _this = this;
      if (this._isExporting)
        return;
      var flush = function() {
        _this._isExporting = true;
        _this._flushOneBatch().finally(function() {
          _this._isExporting = false;
          if (_this._finishedSpans.length > 0) {
            _this._clearTimer();
            _this._maybeStartTimer();
          }
        }).catch(function(e) {
          _this._isExporting = false;
          globalErrorHandler(e);
        });
      };
      if (this._finishedSpans.length >= this._maxExportBatchSize) {
        return flush();
      }
      if (this._timer !== void 0)
        return;
      this._timer = setTimeout(function() {
        return flush();
      }, this._scheduledDelayMillis);
      unrefTimer(this._timer);
    };
    BatchSpanProcessorBase2.prototype._clearTimer = function() {
      if (this._timer !== void 0) {
        clearTimeout(this._timer);
        this._timer = void 0;
      }
    };
    return BatchSpanProcessorBase2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/platform/browser/export/BatchSpanProcessor.js
var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2)
        if (Object.prototype.hasOwnProperty.call(b2, p))
          d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var BatchSpanProcessor = (
  /** @class */
  function(_super) {
    __extends(BatchSpanProcessor2, _super);
    function BatchSpanProcessor2(_exporter, config) {
      var _this = _super.call(this, _exporter, config) || this;
      _this.onInit(config);
      return _this;
    }
    BatchSpanProcessor2.prototype.onInit = function(config) {
      var _this = this;
      if ((config === null || config === void 0 ? void 0 : config.disableAutoFlushOnDocumentHide) !== true && typeof document !== "undefined") {
        this._visibilityChangeListener = function() {
          if (document.visibilityState === "hidden") {
            void _this.forceFlush();
          }
        };
        this._pageHideListener = function() {
          void _this.forceFlush();
        };
        document.addEventListener("visibilitychange", this._visibilityChangeListener);
        document.addEventListener("pagehide", this._pageHideListener);
      }
    };
    BatchSpanProcessor2.prototype.onShutdown = function() {
      if (typeof document !== "undefined") {
        if (this._visibilityChangeListener) {
          document.removeEventListener("visibilitychange", this._visibilityChangeListener);
        }
        if (this._pageHideListener) {
          document.removeEventListener("pagehide", this._pageHideListener);
        }
      }
    };
    return BatchSpanProcessor2;
  }(BatchSpanProcessorBase)
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/platform/browser/RandomIdGenerator.js
var SPAN_ID_BYTES = 8;
var TRACE_ID_BYTES = 16;
var RandomIdGenerator = (
  /** @class */
  /* @__PURE__ */ function() {
    function RandomIdGenerator2() {
      this.generateTraceId = getIdGenerator(TRACE_ID_BYTES);
      this.generateSpanId = getIdGenerator(SPAN_ID_BYTES);
    }
    return RandomIdGenerator2;
  }()
);
var SHARED_CHAR_CODES_ARRAY = Array(32);
function getIdGenerator(bytes) {
  return function generateId() {
    for (var i = 0; i < bytes * 2; i++) {
      SHARED_CHAR_CODES_ARRAY[i] = Math.floor(Math.random() * 16) + 48;
      if (SHARED_CHAR_CODES_ARRAY[i] >= 58) {
        SHARED_CHAR_CODES_ARRAY[i] += 39;
      }
    }
    return String.fromCharCode.apply(null, SHARED_CHAR_CODES_ARRAY.slice(0, bytes * 2));
  };
}

// node_modules/@opentelemetry/sdk-trace-base/build/esm/Tracer.js
var Tracer = (
  /** @class */
  function() {
    function Tracer2(instrumentationLibrary, config, _tracerProvider) {
      this._tracerProvider = _tracerProvider;
      var localConfig = mergeConfig(config);
      this._sampler = localConfig.sampler;
      this._generalLimits = localConfig.generalLimits;
      this._spanLimits = localConfig.spanLimits;
      this._idGenerator = config.idGenerator || new RandomIdGenerator();
      this.resource = _tracerProvider.resource;
      this.instrumentationLibrary = instrumentationLibrary;
    }
    Tracer2.prototype.startSpan = function(name, options, context2) {
      var _a, _b, _c;
      if (options === void 0) {
        options = {};
      }
      if (context2 === void 0) {
        context2 = context.active();
      }
      if (options.root) {
        context2 = trace.deleteSpan(context2);
      }
      var parentSpan = trace.getSpan(context2);
      if (isTracingSuppressed(context2)) {
        diag.debug("Instrumentation suppressed, returning Noop Span");
        var nonRecordingSpan = trace.wrapSpanContext(INVALID_SPAN_CONTEXT);
        return nonRecordingSpan;
      }
      var parentSpanContext = parentSpan === null || parentSpan === void 0 ? void 0 : parentSpan.spanContext();
      var spanId = this._idGenerator.generateSpanId();
      var traceId;
      var traceState;
      var parentSpanId;
      if (!parentSpanContext || !trace.isSpanContextValid(parentSpanContext)) {
        traceId = this._idGenerator.generateTraceId();
      } else {
        traceId = parentSpanContext.traceId;
        traceState = parentSpanContext.traceState;
        parentSpanId = parentSpanContext.spanId;
      }
      var spanKind = (_a = options.kind) !== null && _a !== void 0 ? _a : SpanKind.INTERNAL;
      var links = ((_b = options.links) !== null && _b !== void 0 ? _b : []).map(function(link) {
        return {
          context: link.context,
          attributes: sanitizeAttributes(link.attributes)
        };
      });
      var attributes = sanitizeAttributes(options.attributes);
      var samplingResult = this._sampler.shouldSample(context2, traceId, name, spanKind, attributes, links);
      traceState = (_c = samplingResult.traceState) !== null && _c !== void 0 ? _c : traceState;
      var traceFlags = samplingResult.decision === SamplingDecision.RECORD_AND_SAMPLED ? TraceFlags.SAMPLED : TraceFlags.NONE;
      var spanContext = { traceId, spanId, traceFlags, traceState };
      if (samplingResult.decision === SamplingDecision.NOT_RECORD) {
        diag.debug("Recording is off, propagating context in a non-recording span");
        var nonRecordingSpan = trace.wrapSpanContext(spanContext);
        return nonRecordingSpan;
      }
      var initAttributes = sanitizeAttributes(Object.assign(attributes, samplingResult.attributes));
      var span = new Span(this, context2, name, spanContext, spanKind, parentSpanId, links, options.startTime, void 0, initAttributes);
      return span;
    };
    Tracer2.prototype.startActiveSpan = function(name, arg2, arg3, arg4) {
      var opts;
      var ctx;
      var fn;
      if (arguments.length < 2) {
        return;
      } else if (arguments.length === 2) {
        fn = arg2;
      } else if (arguments.length === 3) {
        opts = arg2;
        fn = arg3;
      } else {
        opts = arg2;
        ctx = arg3;
        fn = arg4;
      }
      var parentContext = ctx !== null && ctx !== void 0 ? ctx : context.active();
      var span = this.startSpan(name, opts, parentContext);
      var contextWithSpanSet = trace.setSpan(parentContext, span);
      return context.with(contextWithSpanSet, fn, void 0, span);
    };
    Tracer2.prototype.getGeneralLimits = function() {
      return this._generalLimits;
    };
    Tracer2.prototype.getSpanLimits = function() {
      return this._spanLimits;
    };
    Tracer2.prototype.getActiveSpanProcessor = function() {
      return this._tracerProvider.getActiveSpanProcessor();
    };
    return Tracer2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/MultiSpanProcessor.js
var __values2 = function(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m)
    return m.call(o);
  if (o && typeof o.length === "number")
    return {
      next: function() {
        if (o && i >= o.length)
          o = void 0;
        return { value: o && o[i++], done: !o };
      }
    };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var MultiSpanProcessor = (
  /** @class */
  function() {
    function MultiSpanProcessor2(_spanProcessors) {
      this._spanProcessors = _spanProcessors;
    }
    MultiSpanProcessor2.prototype.forceFlush = function() {
      var e_1, _a;
      var promises = [];
      try {
        for (var _b = __values2(this._spanProcessors), _c = _b.next(); !_c.done; _c = _b.next()) {
          var spanProcessor = _c.value;
          promises.push(spanProcessor.forceFlush());
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      return new Promise(function(resolve) {
        Promise.all(promises).then(function() {
          resolve();
        }).catch(function(error) {
          globalErrorHandler(error || new Error("MultiSpanProcessor: forceFlush failed"));
          resolve();
        });
      });
    };
    MultiSpanProcessor2.prototype.onStart = function(span, context2) {
      var e_2, _a;
      try {
        for (var _b = __values2(this._spanProcessors), _c = _b.next(); !_c.done; _c = _b.next()) {
          var spanProcessor = _c.value;
          spanProcessor.onStart(span, context2);
        }
      } catch (e_2_1) {
        e_2 = { error: e_2_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_2)
            throw e_2.error;
        }
      }
    };
    MultiSpanProcessor2.prototype.onEnd = function(span) {
      var e_3, _a;
      try {
        for (var _b = __values2(this._spanProcessors), _c = _b.next(); !_c.done; _c = _b.next()) {
          var spanProcessor = _c.value;
          spanProcessor.onEnd(span);
        }
      } catch (e_3_1) {
        e_3 = { error: e_3_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_3)
            throw e_3.error;
        }
      }
    };
    MultiSpanProcessor2.prototype.shutdown = function() {
      var e_4, _a;
      var promises = [];
      try {
        for (var _b = __values2(this._spanProcessors), _c = _b.next(); !_c.done; _c = _b.next()) {
          var spanProcessor = _c.value;
          promises.push(spanProcessor.shutdown());
        }
      } catch (e_4_1) {
        e_4 = { error: e_4_1 };
      } finally {
        try {
          if (_c && !_c.done && (_a = _b.return))
            _a.call(_b);
        } finally {
          if (e_4)
            throw e_4.error;
        }
      }
      return new Promise(function(resolve, reject) {
        Promise.all(promises).then(function() {
          resolve();
        }, reject);
      });
    };
    return MultiSpanProcessor2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/export/NoopSpanProcessor.js
var NoopSpanProcessor = (
  /** @class */
  function() {
    function NoopSpanProcessor2() {
    }
    NoopSpanProcessor2.prototype.onStart = function(_span, _context) {
    };
    NoopSpanProcessor2.prototype.onEnd = function(_span) {
    };
    NoopSpanProcessor2.prototype.shutdown = function() {
      return Promise.resolve();
    };
    NoopSpanProcessor2.prototype.forceFlush = function() {
      return Promise.resolve();
    };
    return NoopSpanProcessor2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/BasicTracerProvider.js
var ForceFlushState;
(function(ForceFlushState2) {
  ForceFlushState2[ForceFlushState2["resolved"] = 0] = "resolved";
  ForceFlushState2[ForceFlushState2["timeout"] = 1] = "timeout";
  ForceFlushState2[ForceFlushState2["error"] = 2] = "error";
  ForceFlushState2[ForceFlushState2["unresolved"] = 3] = "unresolved";
})(ForceFlushState || (ForceFlushState = {}));
var BasicTracerProvider = (
  /** @class */
  function() {
    function BasicTracerProvider2(config) {
      if (config === void 0) {
        config = {};
      }
      var _a;
      this._registeredSpanProcessors = [];
      this._tracers = /* @__PURE__ */ new Map();
      var mergedConfig = merge({}, loadDefaultConfig(), reconfigureLimits(config));
      this.resource = (_a = mergedConfig.resource) !== null && _a !== void 0 ? _a : Resource.empty();
      this.resource = Resource.default().merge(this.resource);
      this._config = Object.assign({}, mergedConfig, {
        resource: this.resource
      });
      var defaultExporter = this._buildExporterFromEnv();
      if (defaultExporter !== void 0) {
        var batchProcessor = new BatchSpanProcessor(defaultExporter);
        this.activeSpanProcessor = batchProcessor;
      } else {
        this.activeSpanProcessor = new NoopSpanProcessor();
      }
    }
    BasicTracerProvider2.prototype.getTracer = function(name, version, options) {
      var key = name + "@" + (version || "") + ":" + ((options === null || options === void 0 ? void 0 : options.schemaUrl) || "");
      if (!this._tracers.has(key)) {
        this._tracers.set(key, new Tracer({ name, version, schemaUrl: options === null || options === void 0 ? void 0 : options.schemaUrl }, this._config, this));
      }
      return this._tracers.get(key);
    };
    BasicTracerProvider2.prototype.addSpanProcessor = function(spanProcessor) {
      if (this._registeredSpanProcessors.length === 0) {
        this.activeSpanProcessor.shutdown().catch(function(err) {
          return diag.error("Error while trying to shutdown current span processor", err);
        });
      }
      this._registeredSpanProcessors.push(spanProcessor);
      this.activeSpanProcessor = new MultiSpanProcessor(this._registeredSpanProcessors);
    };
    BasicTracerProvider2.prototype.getActiveSpanProcessor = function() {
      return this.activeSpanProcessor;
    };
    BasicTracerProvider2.prototype.register = function(config) {
      if (config === void 0) {
        config = {};
      }
      trace.setGlobalTracerProvider(this);
      if (config.propagator === void 0) {
        config.propagator = this._buildPropagatorFromEnv();
      }
      if (config.contextManager) {
        context.setGlobalContextManager(config.contextManager);
      }
      if (config.propagator) {
        propagation.setGlobalPropagator(config.propagator);
      }
    };
    BasicTracerProvider2.prototype.forceFlush = function() {
      var timeout = this._config.forceFlushTimeoutMillis;
      var promises = this._registeredSpanProcessors.map(function(spanProcessor) {
        return new Promise(function(resolve) {
          var state;
          var timeoutInterval = setTimeout(function() {
            resolve(new Error("Span processor did not completed within timeout period of " + timeout + " ms"));
            state = ForceFlushState.timeout;
          }, timeout);
          spanProcessor.forceFlush().then(function() {
            clearTimeout(timeoutInterval);
            if (state !== ForceFlushState.timeout) {
              state = ForceFlushState.resolved;
              resolve(state);
            }
          }).catch(function(error) {
            clearTimeout(timeoutInterval);
            state = ForceFlushState.error;
            resolve(error);
          });
        });
      });
      return new Promise(function(resolve, reject) {
        Promise.all(promises).then(function(results) {
          var errors = results.filter(function(result) {
            return result !== ForceFlushState.resolved;
          });
          if (errors.length > 0) {
            reject(errors);
          } else {
            resolve();
          }
        }).catch(function(error) {
          return reject([error]);
        });
      });
    };
    BasicTracerProvider2.prototype.shutdown = function() {
      return this.activeSpanProcessor.shutdown();
    };
    BasicTracerProvider2.prototype._getPropagator = function(name) {
      var _a;
      return (_a = this.constructor._registeredPropagators.get(name)) === null || _a === void 0 ? void 0 : _a();
    };
    BasicTracerProvider2.prototype._getSpanExporter = function(name) {
      var _a;
      return (_a = this.constructor._registeredExporters.get(name)) === null || _a === void 0 ? void 0 : _a();
    };
    BasicTracerProvider2.prototype._buildPropagatorFromEnv = function() {
      var _this = this;
      var uniquePropagatorNames = Array.from(new Set(getEnv().OTEL_PROPAGATORS));
      var propagators = uniquePropagatorNames.map(function(name) {
        var propagator = _this._getPropagator(name);
        if (!propagator) {
          diag.warn('Propagator "' + name + '" requested through environment variable is unavailable.');
        }
        return propagator;
      });
      var validPropagators = propagators.reduce(function(list, item) {
        if (item) {
          list.push(item);
        }
        return list;
      }, []);
      if (validPropagators.length === 0) {
        return;
      } else if (uniquePropagatorNames.length === 1) {
        return validPropagators[0];
      } else {
        return new CompositePropagator({
          propagators: validPropagators
        });
      }
    };
    BasicTracerProvider2.prototype._buildExporterFromEnv = function() {
      var exporterName = getEnv().OTEL_TRACES_EXPORTER;
      if (exporterName === "none" || exporterName === "")
        return;
      var exporter = this._getSpanExporter(exporterName);
      if (!exporter) {
        diag.error('Exporter "' + exporterName + '" requested through environment variable is unavailable.');
      }
      return exporter;
    };
    BasicTracerProvider2._registeredPropagators = /* @__PURE__ */ new Map([
      ["tracecontext", function() {
        return new W3CTraceContextPropagator();
      }],
      ["baggage", function() {
        return new W3CBaggagePropagator();
      }]
    ]);
    BasicTracerProvider2._registeredExporters = /* @__PURE__ */ new Map();
    return BasicTracerProvider2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/export/ConsoleSpanExporter.js
var __values3 = function(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m)
    return m.call(o);
  if (o && typeof o.length === "number")
    return {
      next: function() {
        if (o && i >= o.length)
          o = void 0;
        return { value: o && o[i++], done: !o };
      }
    };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var ConsoleSpanExporter = (
  /** @class */
  function() {
    function ConsoleSpanExporter2() {
    }
    ConsoleSpanExporter2.prototype.export = function(spans, resultCallback) {
      return this._sendSpans(spans, resultCallback);
    };
    ConsoleSpanExporter2.prototype.shutdown = function() {
      this._sendSpans([]);
      return this.forceFlush();
    };
    ConsoleSpanExporter2.prototype.forceFlush = function() {
      return Promise.resolve();
    };
    ConsoleSpanExporter2.prototype._exportInfo = function(span) {
      var _a;
      return {
        resource: {
          attributes: span.resource.attributes
        },
        instrumentationScope: span.instrumentationLibrary,
        traceId: span.spanContext().traceId,
        parentId: span.parentSpanId,
        traceState: (_a = span.spanContext().traceState) === null || _a === void 0 ? void 0 : _a.serialize(),
        name: span.name,
        id: span.spanContext().spanId,
        kind: span.kind,
        timestamp: hrTimeToMicroseconds(span.startTime),
        duration: hrTimeToMicroseconds(span.duration),
        attributes: span.attributes,
        status: span.status,
        events: span.events,
        links: span.links
      };
    };
    ConsoleSpanExporter2.prototype._sendSpans = function(spans, done) {
      var e_1, _a;
      try {
        for (var spans_1 = __values3(spans), spans_1_1 = spans_1.next(); !spans_1_1.done; spans_1_1 = spans_1.next()) {
          var span = spans_1_1.value;
          console.dir(this._exportInfo(span), { depth: 3 });
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (spans_1_1 && !spans_1_1.done && (_a = spans_1.return))
            _a.call(spans_1);
        } finally {
          if (e_1)
            throw e_1.error;
        }
      }
      if (done) {
        return done({ code: ExportResultCode.SUCCESS });
      }
    };
    return ConsoleSpanExporter2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/export/InMemorySpanExporter.js
var __read2 = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
var __spreadArray2 = function(to, from, pack) {
  if (pack || arguments.length === 2)
    for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar)
          ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var InMemorySpanExporter = (
  /** @class */
  function() {
    function InMemorySpanExporter2() {
      this._finishedSpans = [];
      this._stopped = false;
    }
    InMemorySpanExporter2.prototype.export = function(spans, resultCallback) {
      var _a;
      if (this._stopped)
        return resultCallback({
          code: ExportResultCode.FAILED,
          error: new Error("Exporter has been stopped")
        });
      (_a = this._finishedSpans).push.apply(_a, __spreadArray2([], __read2(spans), false));
      setTimeout(function() {
        return resultCallback({ code: ExportResultCode.SUCCESS });
      }, 0);
    };
    InMemorySpanExporter2.prototype.shutdown = function() {
      this._stopped = true;
      this._finishedSpans = [];
      return this.forceFlush();
    };
    InMemorySpanExporter2.prototype.forceFlush = function() {
      return Promise.resolve();
    };
    InMemorySpanExporter2.prototype.reset = function() {
      this._finishedSpans = [];
    };
    InMemorySpanExporter2.prototype.getFinishedSpans = function() {
      return this._finishedSpans;
    };
    return InMemorySpanExporter2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-base/build/esm/export/SimpleSpanProcessor.js
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1)
      throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f)
      throw new TypeError("Generator is already executing.");
    while (_)
      try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
          return t;
        if (y = 0, t)
          op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2])
              _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
    if (op[0] & 5)
      throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var SimpleSpanProcessor = (
  /** @class */
  function() {
    function SimpleSpanProcessor2(_exporter) {
      this._exporter = _exporter;
      this._shutdownOnce = new BindOnceFuture(this._shutdown, this);
      this._unresolvedExports = /* @__PURE__ */ new Set();
    }
    SimpleSpanProcessor2.prototype.forceFlush = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, Promise.all(Array.from(this._unresolvedExports))];
            case 1:
              _a.sent();
              if (!this._exporter.forceFlush)
                return [3, 3];
              return [4, this._exporter.forceFlush()];
            case 2:
              _a.sent();
              _a.label = 3;
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    SimpleSpanProcessor2.prototype.onStart = function(_span, _parentContext) {
    };
    SimpleSpanProcessor2.prototype.onEnd = function(span) {
      var _this = this;
      var _a, _b;
      if (this._shutdownOnce.isCalled) {
        return;
      }
      if ((span.spanContext().traceFlags & TraceFlags.SAMPLED) === 0) {
        return;
      }
      var doExport = function() {
        return internal._export(_this._exporter, [span]).then(function(result) {
          var _a2;
          if (result.code !== ExportResultCode.SUCCESS) {
            globalErrorHandler((_a2 = result.error) !== null && _a2 !== void 0 ? _a2 : new Error("SimpleSpanProcessor: span export failed (status " + result + ")"));
          }
        }).catch(function(error) {
          globalErrorHandler(error);
        });
      };
      if (span.resource.asyncAttributesPending) {
        var exportPromise_1 = (_b = (_a = span.resource).waitForAsyncAttributes) === null || _b === void 0 ? void 0 : _b.call(_a).then(function() {
          if (exportPromise_1 != null) {
            _this._unresolvedExports.delete(exportPromise_1);
          }
          return doExport();
        }, function(err) {
          return globalErrorHandler(err);
        });
        if (exportPromise_1 != null) {
          this._unresolvedExports.add(exportPromise_1);
        }
      } else {
        void doExport();
      }
    };
    SimpleSpanProcessor2.prototype.shutdown = function() {
      return this._shutdownOnce.call();
    };
    SimpleSpanProcessor2.prototype._shutdown = function() {
      return this._exporter.shutdown();
    };
    return SimpleSpanProcessor2;
  }()
);

export {
  Span,
  SamplingDecision2 as SamplingDecision,
  AlwaysOffSampler,
  AlwaysOnSampler,
  ParentBasedSampler,
  TraceIdRatioBasedSampler,
  BatchSpanProcessor,
  RandomIdGenerator,
  Tracer,
  NoopSpanProcessor,
  ForceFlushState,
  BasicTracerProvider,
  ConsoleSpanExporter,
  InMemorySpanExporter,
  SimpleSpanProcessor
};
//# sourceMappingURL=chunk-YUPDH3JR.js.map
