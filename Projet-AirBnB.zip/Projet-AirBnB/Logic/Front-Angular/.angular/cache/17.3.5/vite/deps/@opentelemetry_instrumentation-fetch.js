import {
  PerformanceTimingNames,
  addSpanNetworkEvents,
  getResource,
  parseUrl,
  shouldPropagateTraceHeaders
} from "./chunk-VCIPMLAT.js";
import "./chunk-YUPDH3JR.js";
import {
  InstrumentationBase,
  isWrapped,
  safeExecuteInTheMiddle
} from "./chunk-2S52PPVH.js";
import {
  SEMATTRS_HTTP_HOST,
  SEMATTRS_HTTP_METHOD,
  SEMATTRS_HTTP_SCHEME,
  SEMATTRS_HTTP_STATUS_CODE,
  SEMATTRS_HTTP_URL,
  SEMATTRS_HTTP_USER_AGENT,
  _globalThis,
  hrTime,
  isUrlIgnored,
  millisToHrTime
} from "./chunk-FT7YRNA4.js";
import {
  SpanKind,
  context,
  propagation,
  trace
} from "./chunk-UXK5IXEU.js";
import "./chunk-ASLTLD6L.js";

// node_modules/@opentelemetry/instrumentation-fetch/build/esm/enums/AttributeNames.js
var AttributeNames;
(function(AttributeNames2) {
  AttributeNames2["COMPONENT"] = "component";
  AttributeNames2["HTTP_ERROR_NAME"] = "http.error_name";
  AttributeNames2["HTTP_STATUS_TEXT"] = "http.status_text";
})(AttributeNames || (AttributeNames = {}));

// node_modules/@opentelemetry/instrumentation-fetch/build/esm/version.js
var VERSION = "0.54.2";

// node_modules/@opentelemetry/instrumentation-fetch/build/esm/fetch.js
var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2)
        if (Object.prototype.hasOwnProperty.call(b2, p))
          d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var _a;
var OBSERVER_WAIT_TIME_MS = 300;
var isNode = typeof process === "object" && ((_a = process.release) === null || _a === void 0 ? void 0 : _a.name) === "node";
var FetchInstrumentation = (
  /** @class */
  function(_super) {
    __extends(FetchInstrumentation2, _super);
    function FetchInstrumentation2(config) {
      if (config === void 0) {
        config = {};
      }
      var _this = _super.call(this, "@opentelemetry/instrumentation-fetch", VERSION, config) || this;
      _this.component = "fetch";
      _this.version = VERSION;
      _this.moduleName = _this.component;
      _this._usedResources = /* @__PURE__ */ new WeakSet();
      _this._tasksCount = 0;
      return _this;
    }
    FetchInstrumentation2.prototype.init = function() {
    };
    FetchInstrumentation2.prototype._addChildSpan = function(span, corsPreFlightRequest) {
      var childSpan = this.tracer.startSpan("CORS Preflight", {
        startTime: corsPreFlightRequest[PerformanceTimingNames.FETCH_START]
      }, trace.setSpan(context.active(), span));
      if (!this.getConfig().ignoreNetworkEvents) {
        addSpanNetworkEvents(childSpan, corsPreFlightRequest);
      }
      childSpan.end(corsPreFlightRequest[PerformanceTimingNames.RESPONSE_END]);
    };
    FetchInstrumentation2.prototype._addFinalSpanAttributes = function(span, response) {
      var parsedUrl = parseUrl(response.url);
      span.setAttribute(SEMATTRS_HTTP_STATUS_CODE, response.status);
      if (response.statusText != null) {
        span.setAttribute(AttributeNames.HTTP_STATUS_TEXT, response.statusText);
      }
      span.setAttribute(SEMATTRS_HTTP_HOST, parsedUrl.host);
      span.setAttribute(SEMATTRS_HTTP_SCHEME, parsedUrl.protocol.replace(":", ""));
      if (typeof navigator !== "undefined") {
        span.setAttribute(SEMATTRS_HTTP_USER_AGENT, navigator.userAgent);
      }
    };
    FetchInstrumentation2.prototype._addHeaders = function(options, spanUrl) {
      if (!shouldPropagateTraceHeaders(spanUrl, this.getConfig().propagateTraceHeaderCorsUrls)) {
        var headers = {};
        propagation.inject(context.active(), headers);
        if (Object.keys(headers).length > 0) {
          this._diag.debug("headers inject skipped due to CORS policy");
        }
        return;
      }
      if (options instanceof Request) {
        propagation.inject(context.active(), options.headers, {
          set: function(h, k, v) {
            return h.set(k, typeof v === "string" ? v : String(v));
          }
        });
      } else if (options.headers instanceof Headers) {
        propagation.inject(context.active(), options.headers, {
          set: function(h, k, v) {
            return h.set(k, typeof v === "string" ? v : String(v));
          }
        });
      } else if (options.headers instanceof Map) {
        propagation.inject(context.active(), options.headers, {
          set: function(h, k, v) {
            return h.set(k, typeof v === "string" ? v : String(v));
          }
        });
      } else {
        var headers = {};
        propagation.inject(context.active(), headers);
        options.headers = Object.assign({}, headers, options.headers || {});
      }
    };
    FetchInstrumentation2.prototype._clearResources = function() {
      if (this._tasksCount === 0 && this.getConfig().clearTimingResources) {
        performance.clearResourceTimings();
        this._usedResources = /* @__PURE__ */ new WeakSet();
      }
    };
    FetchInstrumentation2.prototype._createSpan = function(url, options) {
      var _a2;
      if (options === void 0) {
        options = {};
      }
      if (isUrlIgnored(url, this.getConfig().ignoreUrls)) {
        this._diag.debug("ignoring span as url matches ignored url");
        return;
      }
      var method = (options.method || "GET").toUpperCase();
      var spanName = "HTTP " + method;
      return this.tracer.startSpan(spanName, {
        kind: SpanKind.CLIENT,
        attributes: (_a2 = {}, _a2[AttributeNames.COMPONENT] = this.moduleName, _a2[SEMATTRS_HTTP_METHOD] = method, _a2[SEMATTRS_HTTP_URL] = url, _a2)
      });
    };
    FetchInstrumentation2.prototype._findResourceAndAddNetworkEvents = function(span, resourcesObserver, endTime) {
      var resources = resourcesObserver.entries;
      if (!resources.length) {
        if (!performance.getEntriesByType) {
          return;
        }
        resources = performance.getEntriesByType("resource");
      }
      var resource = getResource(resourcesObserver.spanUrl, resourcesObserver.startTime, endTime, resources, this._usedResources, "fetch");
      if (resource.mainRequest) {
        var mainRequest = resource.mainRequest;
        this._markResourceAsUsed(mainRequest);
        var corsPreFlightRequest = resource.corsPreFlightRequest;
        if (corsPreFlightRequest) {
          this._addChildSpan(span, corsPreFlightRequest);
          this._markResourceAsUsed(corsPreFlightRequest);
        }
        if (!this.getConfig().ignoreNetworkEvents) {
          addSpanNetworkEvents(span, mainRequest);
        }
      }
    };
    FetchInstrumentation2.prototype._markResourceAsUsed = function(resource) {
      this._usedResources.add(resource);
    };
    FetchInstrumentation2.prototype._endSpan = function(span, spanData, response) {
      var _this = this;
      var endTime = millisToHrTime(Date.now());
      var performanceEndTime = hrTime();
      this._addFinalSpanAttributes(span, response);
      setTimeout(function() {
        var _a2;
        (_a2 = spanData.observer) === null || _a2 === void 0 ? void 0 : _a2.disconnect();
        _this._findResourceAndAddNetworkEvents(span, spanData, performanceEndTime);
        _this._tasksCount--;
        _this._clearResources();
        span.end(endTime);
      }, OBSERVER_WAIT_TIME_MS);
    };
    FetchInstrumentation2.prototype._patchConstructor = function() {
      var _this = this;
      return function(original) {
        var plugin = _this;
        return function patchConstructor() {
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
            args[_i] = arguments[_i];
          }
          var self = this;
          var url = parseUrl(args[0] instanceof Request ? args[0].url : String(args[0])).href;
          var options = args[0] instanceof Request ? args[0] : args[1] || {};
          var createdSpan = plugin._createSpan(url, options);
          if (!createdSpan) {
            return original.apply(this, args);
          }
          var spanData = plugin._prepareSpanData(url);
          function endSpanOnError(span, error) {
            plugin._applyAttributesAfterFetch(span, options, error);
            plugin._endSpan(span, spanData, {
              status: error.status || 0,
              statusText: error.message,
              url
            });
          }
          function endSpanOnSuccess(span, response) {
            plugin._applyAttributesAfterFetch(span, options, response);
            if (response.status >= 200 && response.status < 400) {
              plugin._endSpan(span, spanData, response);
            } else {
              plugin._endSpan(span, spanData, {
                status: response.status,
                statusText: response.statusText,
                url
              });
            }
          }
          function onSuccess(span, resolve, response) {
            try {
              var resClone = response.clone();
              var resClone4Hook_1 = response.clone();
              var body = resClone.body;
              if (body) {
                var reader_1 = body.getReader();
                var read_1 = function() {
                  reader_1.read().then(function(_a2) {
                    var done = _a2.done;
                    if (done) {
                      endSpanOnSuccess(span, resClone4Hook_1);
                    } else {
                      read_1();
                    }
                  }, function(error) {
                    endSpanOnError(span, error);
                  });
                };
                read_1();
              } else {
                endSpanOnSuccess(span, response);
              }
            } finally {
              resolve(response);
            }
          }
          function onError(span, reject, error) {
            try {
              endSpanOnError(span, error);
            } finally {
              reject(error);
            }
          }
          return new Promise(function(resolve, reject) {
            return context.with(trace.setSpan(context.active(), createdSpan), function() {
              plugin._addHeaders(options, url);
              plugin._tasksCount++;
              return original.apply(self, options instanceof Request ? [options] : [url, options]).then(onSuccess.bind(self, createdSpan, resolve), onError.bind(self, createdSpan, reject));
            });
          });
        };
      };
    };
    FetchInstrumentation2.prototype._applyAttributesAfterFetch = function(span, request, result) {
      var _this = this;
      var applyCustomAttributesOnSpan = this.getConfig().applyCustomAttributesOnSpan;
      if (applyCustomAttributesOnSpan) {
        safeExecuteInTheMiddle(function() {
          return applyCustomAttributesOnSpan(span, request, result);
        }, function(error) {
          if (!error) {
            return;
          }
          _this._diag.error("applyCustomAttributesOnSpan", error);
        }, true);
      }
    };
    FetchInstrumentation2.prototype._prepareSpanData = function(spanUrl) {
      var startTime = hrTime();
      var entries = [];
      if (typeof PerformanceObserver !== "function") {
        return { entries, startTime, spanUrl };
      }
      var observer = new PerformanceObserver(function(list) {
        var perfObsEntries = list.getEntries();
        perfObsEntries.forEach(function(entry) {
          if (entry.initiatorType === "fetch" && entry.name === spanUrl) {
            entries.push(entry);
          }
        });
      });
      observer.observe({
        entryTypes: ["resource"]
      });
      return { entries, observer, startTime, spanUrl };
    };
    FetchInstrumentation2.prototype.enable = function() {
      if (isNode) {
        this._diag.warn("this instrumentation is intended for web usage only, it does not instrument Node.js's fetch()");
        return;
      }
      if (isWrapped(fetch)) {
        this._unwrap(_globalThis, "fetch");
        this._diag.debug("removing previous patch for constructor");
      }
      this._wrap(_globalThis, "fetch", this._patchConstructor());
    };
    FetchInstrumentation2.prototype.disable = function() {
      if (isNode) {
        return;
      }
      this._unwrap(_globalThis, "fetch");
      this._usedResources = /* @__PURE__ */ new WeakSet();
    };
    return FetchInstrumentation2;
  }(InstrumentationBase)
);
export {
  FetchInstrumentation
};
//# sourceMappingURL=@opentelemetry_instrumentation-fetch.js.map
