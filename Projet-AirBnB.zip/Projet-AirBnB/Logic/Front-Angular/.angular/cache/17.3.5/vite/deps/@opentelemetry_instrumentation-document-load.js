import {
  PerformanceTimingNames,
  addSpanNetworkEvent,
  addSpanNetworkEvents,
  hasKey
} from "./chunk-VCIPMLAT.js";
import "./chunk-YUPDH3JR.js";
import {
  InstrumentationBase,
  safeExecuteInTheMiddle
} from "./chunk-2S52PPVH.js";
import {
  SEMATTRS_HTTP_URL,
  SEMATTRS_HTTP_USER_AGENT,
  TRACE_PARENT_HEADER,
  otperformance
} from "./chunk-FT7YRNA4.js";
import {
  ROOT_CONTEXT,
  context,
  propagation,
  trace
} from "./chunk-UXK5IXEU.js";
import "./chunk-ASLTLD6L.js";

// node_modules/@opentelemetry/instrumentation-document-load/build/esm/enums/AttributeNames.js
var AttributeNames;
(function(AttributeNames2) {
  AttributeNames2["DOCUMENT_LOAD"] = "documentLoad";
  AttributeNames2["DOCUMENT_FETCH"] = "documentFetch";
  AttributeNames2["RESOURCE_FETCH"] = "resourceFetch";
})(AttributeNames || (AttributeNames = {}));

// node_modules/@opentelemetry/instrumentation-document-load/build/esm/version.js
var PACKAGE_VERSION = "0.41.0";
var PACKAGE_NAME = "@opentelemetry/instrumentation-document-load";

// node_modules/@opentelemetry/instrumentation-document-load/build/esm/enums/EventNames.js
var EventNames;
(function(EventNames2) {
  EventNames2["FIRST_PAINT"] = "firstPaint";
  EventNames2["FIRST_CONTENTFUL_PAINT"] = "firstContentfulPaint";
})(EventNames || (EventNames = {}));

// node_modules/@opentelemetry/instrumentation-document-load/build/esm/utils.js
var getPerformanceNavigationEntries = function() {
  var _a, _b;
  var entries = {};
  var performanceNavigationTiming = (_b = (_a = otperformance).getEntriesByType) === null || _b === void 0 ? void 0 : _b.call(_a, "navigation")[0];
  if (performanceNavigationTiming) {
    var keys = Object.values(PerformanceTimingNames);
    keys.forEach(function(key) {
      if (hasKey(performanceNavigationTiming, key)) {
        var value = performanceNavigationTiming[key];
        if (typeof value === "number") {
          entries[key] = value;
        }
      }
    });
  } else {
    var perf = otperformance;
    var performanceTiming_1 = perf.timing;
    if (performanceTiming_1) {
      var keys = Object.values(PerformanceTimingNames);
      keys.forEach(function(key) {
        if (hasKey(performanceTiming_1, key)) {
          var value = performanceTiming_1[key];
          if (typeof value === "number") {
            entries[key] = value;
          }
        }
      });
    }
  }
  return entries;
};
var performancePaintNames = {
  "first-paint": EventNames.FIRST_PAINT,
  "first-contentful-paint": EventNames.FIRST_CONTENTFUL_PAINT
};
var addSpanPerformancePaintEvents = function(span) {
  var _a, _b;
  var performancePaintTiming = (_b = (_a = otperformance).getEntriesByType) === null || _b === void 0 ? void 0 : _b.call(_a, "paint");
  if (performancePaintTiming) {
    performancePaintTiming.forEach(function(_a2) {
      var name = _a2.name, startTime = _a2.startTime;
      if (hasKey(performancePaintNames, name)) {
        span.addEvent(performancePaintNames[name], startTime);
      }
    });
  }
};

// node_modules/@opentelemetry/instrumentation-document-load/build/esm/instrumentation.js
var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2)
        if (Object.prototype.hasOwnProperty.call(b2, p))
          d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var DocumentLoadInstrumentation = (
  /** @class */
  function(_super) {
    __extends(DocumentLoadInstrumentation2, _super);
    function DocumentLoadInstrumentation2(config) {
      if (config === void 0) {
        config = {};
      }
      var _this = _super.call(this, PACKAGE_NAME, PACKAGE_VERSION, config) || this;
      _this.component = "document-load";
      _this.version = "1";
      _this.moduleName = _this.component;
      return _this;
    }
    DocumentLoadInstrumentation2.prototype.init = function() {
    };
    DocumentLoadInstrumentation2.prototype._onDocumentLoaded = function() {
      var _this = this;
      window.setTimeout(function() {
        _this._collectPerformance();
      });
    };
    DocumentLoadInstrumentation2.prototype._addResourcesSpans = function(rootSpan) {
      var _this = this;
      var _a, _b;
      var resources = (_b = (_a = otperformance).getEntriesByType) === null || _b === void 0 ? void 0 : _b.call(_a, "resource");
      if (resources) {
        resources.forEach(function(resource) {
          _this._initResourceSpan(resource, rootSpan);
        });
      }
    };
    DocumentLoadInstrumentation2.prototype._collectPerformance = function() {
      var _this = this;
      var metaElement = Array.from(document.getElementsByTagName("meta")).find(function(e) {
        return e.getAttribute("name") === TRACE_PARENT_HEADER;
      });
      var entries = getPerformanceNavigationEntries();
      var traceparent = metaElement && metaElement.content || "";
      context.with(propagation.extract(ROOT_CONTEXT, { traceparent }), function() {
        var _a;
        var rootSpan = _this._startSpan(AttributeNames.DOCUMENT_LOAD, PerformanceTimingNames.FETCH_START, entries);
        if (!rootSpan) {
          return;
        }
        context.with(trace.setSpan(context.active(), rootSpan), function() {
          var fetchSpan = _this._startSpan(AttributeNames.DOCUMENT_FETCH, PerformanceTimingNames.FETCH_START, entries);
          if (fetchSpan) {
            fetchSpan.setAttribute(SEMATTRS_HTTP_URL, location.href);
            context.with(trace.setSpan(context.active(), fetchSpan), function() {
              var _a2;
              if (!_this.getConfig().ignoreNetworkEvents) {
                addSpanNetworkEvents(fetchSpan, entries);
              }
              _this._addCustomAttributesOnSpan(fetchSpan, (_a2 = _this.getConfig().applyCustomAttributesOnSpan) === null || _a2 === void 0 ? void 0 : _a2.documentFetch);
              _this._endSpan(fetchSpan, PerformanceTimingNames.RESPONSE_END, entries);
            });
          }
        });
        rootSpan.setAttribute(SEMATTRS_HTTP_URL, location.href);
        rootSpan.setAttribute(SEMATTRS_HTTP_USER_AGENT, navigator.userAgent);
        _this._addResourcesSpans(rootSpan);
        if (!_this.getConfig().ignoreNetworkEvents) {
          addSpanNetworkEvent(rootSpan, PerformanceTimingNames.FETCH_START, entries);
          addSpanNetworkEvent(rootSpan, PerformanceTimingNames.UNLOAD_EVENT_START, entries);
          addSpanNetworkEvent(rootSpan, PerformanceTimingNames.UNLOAD_EVENT_END, entries);
          addSpanNetworkEvent(rootSpan, PerformanceTimingNames.DOM_INTERACTIVE, entries);
          addSpanNetworkEvent(rootSpan, PerformanceTimingNames.DOM_CONTENT_LOADED_EVENT_START, entries);
          addSpanNetworkEvent(rootSpan, PerformanceTimingNames.DOM_CONTENT_LOADED_EVENT_END, entries);
          addSpanNetworkEvent(rootSpan, PerformanceTimingNames.DOM_COMPLETE, entries);
          addSpanNetworkEvent(rootSpan, PerformanceTimingNames.LOAD_EVENT_START, entries);
          addSpanNetworkEvent(rootSpan, PerformanceTimingNames.LOAD_EVENT_END, entries);
        }
        if (!_this.getConfig().ignorePerformancePaintEvents) {
          addSpanPerformancePaintEvents(rootSpan);
        }
        _this._addCustomAttributesOnSpan(rootSpan, (_a = _this.getConfig().applyCustomAttributesOnSpan) === null || _a === void 0 ? void 0 : _a.documentLoad);
        _this._endSpan(rootSpan, PerformanceTimingNames.LOAD_EVENT_END, entries);
      });
    };
    DocumentLoadInstrumentation2.prototype._endSpan = function(span, performanceName, entries) {
      if (span) {
        if (hasKey(entries, performanceName)) {
          span.end(entries[performanceName]);
        } else {
          span.end();
        }
      }
    };
    DocumentLoadInstrumentation2.prototype._initResourceSpan = function(resource, parentSpan) {
      var _a;
      var span = this._startSpan(AttributeNames.RESOURCE_FETCH, PerformanceTimingNames.FETCH_START, resource, parentSpan);
      if (span) {
        span.setAttribute(SEMATTRS_HTTP_URL, resource.name);
        if (!this.getConfig().ignoreNetworkEvents) {
          addSpanNetworkEvents(span, resource);
        }
        this._addCustomAttributesOnResourceSpan(span, resource, (_a = this.getConfig().applyCustomAttributesOnSpan) === null || _a === void 0 ? void 0 : _a.resourceFetch);
        this._endSpan(span, PerformanceTimingNames.RESPONSE_END, resource);
      }
    };
    DocumentLoadInstrumentation2.prototype._startSpan = function(spanName, performanceName, entries, parentSpan) {
      if (hasKey(entries, performanceName) && typeof entries[performanceName] === "number") {
        var span = this.tracer.startSpan(spanName, {
          startTime: entries[performanceName]
        }, parentSpan ? trace.setSpan(context.active(), parentSpan) : void 0);
        return span;
      }
      return void 0;
    };
    DocumentLoadInstrumentation2.prototype._waitForPageLoad = function() {
      if (window.document.readyState === "complete") {
        this._onDocumentLoaded();
      } else {
        this._onDocumentLoaded = this._onDocumentLoaded.bind(this);
        window.addEventListener("load", this._onDocumentLoaded);
      }
    };
    DocumentLoadInstrumentation2.prototype._addCustomAttributesOnSpan = function(span, applyCustomAttributesOnSpan) {
      var _this = this;
      if (applyCustomAttributesOnSpan) {
        safeExecuteInTheMiddle(function() {
          return applyCustomAttributesOnSpan(span);
        }, function(error) {
          if (!error) {
            return;
          }
          _this._diag.error("addCustomAttributesOnSpan", error);
        }, true);
      }
    };
    DocumentLoadInstrumentation2.prototype._addCustomAttributesOnResourceSpan = function(span, resource, applyCustomAttributesOnSpan) {
      var _this = this;
      if (applyCustomAttributesOnSpan) {
        safeExecuteInTheMiddle(function() {
          return applyCustomAttributesOnSpan(span, resource);
        }, function(error) {
          if (!error) {
            return;
          }
          _this._diag.error("addCustomAttributesOnResourceSpan", error);
        }, true);
      }
    };
    DocumentLoadInstrumentation2.prototype.enable = function() {
      window.removeEventListener("load", this._onDocumentLoaded);
      this._waitForPageLoad();
    };
    DocumentLoadInstrumentation2.prototype.disable = function() {
      window.removeEventListener("load", this._onDocumentLoaded);
    };
    return DocumentLoadInstrumentation2;
  }(InstrumentationBase)
);
export {
  AttributeNames,
  DocumentLoadInstrumentation
};
//# sourceMappingURL=@opentelemetry_instrumentation-document-load.js.map
