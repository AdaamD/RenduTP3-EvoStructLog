import {
  CommonModule,
  NgIf
} from "./chunk-WZQFT5IY.js";
import {
  Component,
  Input,
  NO_ERRORS_SCHEMA,
  NgModule,
  ViewChild,
  setClassMetadata,
  ɵɵNgOnChangesFeature,
  ɵɵadvance,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵelement,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵqueryRefresh,
  ɵɵstyleMap,
  ɵɵtemplate,
  ɵɵviewQuery
} from "./chunk-SBUSRXC3.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-ASLTLD6L.js";

// node_modules/sdk-loading/fesm2022/sdk-loading.mjs
function SDKLoadingComponent_div_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 4);
    ɵɵelement(1, "div", 5);
    ɵɵelementEnd();
  }
}
function SDKLoadingComponent_div_0_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 6);
    ɵɵelement(1, "div", 5);
    ɵɵelementEnd();
  }
}
function SDKLoadingComponent_div_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 1);
    ɵɵtemplate(1, SDKLoadingComponent_div_0_div_1_Template, 2, 0, "div", 2)(2, SDKLoadingComponent_div_0_div_2_Template, 2, 0, "div", 3);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵstyleMap(ctx_r0.style);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.isLoading && !ctx_r0.showEllipsis);
    ɵɵadvance();
    ɵɵproperty("ngIf", ctx_r0.isLoading && ctx_r0.showEllipsis);
  }
}
var _SDKLoadingComponent = class _SDKLoadingComponent {
  constructor() {
    this.isLoading = false;
    this.showEllipsis = false;
    this.style = "";
  }
};
_SDKLoadingComponent.ɵfac = function SDKLoadingComponent_Factory(t) {
  return new (t || _SDKLoadingComponent)();
};
_SDKLoadingComponent.ɵcmp = ɵɵdefineComponent({
  type: _SDKLoadingComponent,
  selectors: [["sdk-loading"]],
  inputs: {
    isLoading: "isLoading",
    showEllipsis: "showEllipsis",
    style: "style"
  },
  decls: 1,
  vars: 1,
  consts: [["class", "sdk-loading", 3, "style", 4, "ngIf"], [1, "sdk-loading"], ["class", "spinner", 4, "ngIf"], ["class", "ellipsis", 4, "ngIf"], [1, "spinner"], [1, "sdk-loading-icon"], [1, "ellipsis"]],
  template: function SDKLoadingComponent_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵtemplate(0, SDKLoadingComponent_div_0_Template, 3, 4, "div", 0);
    }
    if (rf & 2) {
      ɵɵproperty("ngIf", ctx.isLoading);
    }
  },
  dependencies: [NgIf],
  styles: ['@charset "UTF-8";.sdk-loading[_ngcontent-%COMP%]{position:absolute;inset:0;z-index:9999;overflow:hidden;background-color:#000;opacity:.33}.sdk-loading[_ngcontent-%COMP%]   .spinner[_ngcontent-%COMP%]{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);overflow:hidden}.sdk-loading[_ngcontent-%COMP%]   .spinner[_ngcontent-%COMP%]   .sdk-loading-icon[_ngcontent-%COMP%]{height:75px;width:75px;border-radius:50%;position:relative;border:3px solid #2d2d2d;border-right:3px solid white;animation:_ngcontent-%COMP%_spin 1s linear infinite}@keyframes _ngcontent-%COMP%_spin{to{transform:rotate(360deg)}}.sdk-loading[_ngcontent-%COMP%]   .ellipsis[_ngcontent-%COMP%]   .sdk-loading-icon[_ngcontent-%COMP%]{font-size:30px;font-weight:700;color:#fff}.sdk-loading[_ngcontent-%COMP%]   .ellipsis[_ngcontent-%COMP%]   .sdk-loading-icon[_ngcontent-%COMP%]:after{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);overflow:hidden;display:inline-block;animation:_ngcontent-%COMP%_ellipsis steps(4,end) 1s infinite;content:"\\2026";margin:-8px 0;padding:0;width:0px}@keyframes _ngcontent-%COMP%_ellipsis{to{width:1em}}']
});
var SDKLoadingComponent = _SDKLoadingComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SDKLoadingComponent, [{
    type: Component,
    args: [{
      selector: "sdk-loading",
      template: '<div *ngIf="isLoading" class="sdk-loading" [style]="style">\n    <div *ngIf="isLoading && !showEllipsis" class="spinner">\n        <div class="sdk-loading-icon"></div>\n    </div>\n    <div *ngIf="isLoading && showEllipsis" class="ellipsis">\n        <div class="sdk-loading-icon"></div>\n    </div>\n</div>\n',
      styles: ['@charset "UTF-8";.sdk-loading{position:absolute;inset:0;z-index:9999;overflow:hidden;background-color:#000;opacity:.33}.sdk-loading .spinner{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);overflow:hidden}.sdk-loading .spinner .sdk-loading-icon{height:75px;width:75px;border-radius:50%;position:relative;border:3px solid #2d2d2d;border-right:3px solid white;animation:spin 1s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}.sdk-loading .ellipsis .sdk-loading-icon{font-size:30px;font-weight:700;color:#fff}.sdk-loading .ellipsis .sdk-loading-icon:after{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);overflow:hidden;display:inline-block;animation:ellipsis steps(4,end) 1s infinite;content:"\\2026";margin:-8px 0;padding:0;width:0px}@keyframes ellipsis{to{width:1em}}\n']
    }]
  }], null, {
    isLoading: [{
      type: Input
    }],
    showEllipsis: [{
      type: Input
    }],
    style: [{
      type: Input
    }]
  });
})();
var _SDKLoadingModule = class _SDKLoadingModule {
};
_SDKLoadingModule.ɵfac = function SDKLoadingModule_Factory(t) {
  return new (t || _SDKLoadingModule)();
};
_SDKLoadingModule.ɵmod = ɵɵdefineNgModule({
  type: _SDKLoadingModule,
  declarations: [SDKLoadingComponent],
  imports: [CommonModule],
  exports: [SDKLoadingComponent]
});
_SDKLoadingModule.ɵinj = ɵɵdefineInjector({
  imports: [CommonModule]
});
var SDKLoadingModule = _SDKLoadingModule;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SDKLoadingModule, [{
    type: NgModule,
    args: [{
      declarations: [SDKLoadingComponent],
      imports: [CommonModule],
      exports: [SDKLoadingComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }]
  }], null, null);
})();

// node_modules/sdk-google-map/fesm2022/sdk-google-map.mjs
var _c0 = ["map"];
var _SDKGoogleMapComponent = class _SDKGoogleMapComponent {
  constructor() {
    this.height = "";
    this.width = "";
    this.latitude = "";
    this.longitude = "";
    this.location = "";
    this.zoom = "10";
    this.border = "1px solid lightgray";
    this.isLoading = false;
    this._height = "";
    this._width = "";
  }
  /**************************************************************************
  * Component Lifecycle Methods
  **************************************************************************/
  ngOnChanges(_args) {
    if (_args.latitude || _args.longitude || _args.location || _args.zoom) {
      if (_args.latitude !== "" || _args.longitude !== "" || _args.location !== "") {
        this.loadMap();
      }
    }
    if (_args.height && _args.height !== "" || _args.width && _args.width !== "") {
      this.setMap();
    }
  }
  /**************************************************************************
  * Private Methods
  **************************************************************************/
  setMap() {
    if (this.height !== "" && this.width === "") {
      this._height = this.height;
      this._width = this.height;
    } else if (this.height === "" && this.width !== "") {
      this._height = this.width;
      this._width = this.width;
    } else if (this.height !== "" && this.width !== "") {
      this._height = this.height;
      this._width = this.width;
    } else {
      this._height = "300px";
      this._width = "300px";
    }
  }
  loadMap() {
    this.isLoading = true;
    let src = "";
    if (this.latitude && this.latitude !== "" && this.longitude && this.longitude !== "") {
      src = `<iframe id="sdk-google-map-iframe" width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=100%25&amp;hl=en&amp;q=${this.latitude},${this.longitude}&amp;t=&amp;z=${this.zoom}&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>`;
    } else if (this.location && this.location !== "") {
      src = `<iframe id="sdk-google-map-iframe" width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=100%25&amp;hl=en&amp;q=${encodeURI(this.location)}&amp;t=&amp;z=${this.zoom}&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>`;
    } else {
      src = `<div style="display: flex; width: 100%; height: 100%; align-items: center;"><div style="width: 100%; text-align: center;">Insufficient data.</div></div>`;
    }
    setTimeout(() => {
      this.map.nativeElement.innerHTML = src ?? "";
      let iframe = document.getElementById("sdk-google-map-iframe");
      if (iframe) {
        iframe.onload = () => {
          this.isLoading = false;
        };
      } else {
        this.isLoading = false;
      }
    }, 100);
  }
};
_SDKGoogleMapComponent.ɵfac = function SDKGoogleMapComponent_Factory(t) {
  return new (t || _SDKGoogleMapComponent)();
};
_SDKGoogleMapComponent.ɵcmp = ɵɵdefineComponent({
  type: _SDKGoogleMapComponent,
  selectors: [["sdk-google-map"]],
  viewQuery: function SDKGoogleMapComponent_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c0, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.map = _t.first);
    }
  },
  inputs: {
    height: "height",
    width: "width",
    latitude: "latitude",
    longitude: "longitude",
    location: "location",
    zoom: "zoom",
    border: "border"
  },
  features: [ɵɵNgOnChangesFeature],
  decls: 4,
  vars: 3,
  consts: [["map", ""], [2, "height", "100%", "width", "100%"], [3, "isLoading"]],
  template: function SDKGoogleMapComponent_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div");
      ɵɵelement(1, "div", 1, 0)(3, "sdk-loading", 2);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵstyleMap("position: relative; height: " + ctx._height + "; width: " + ctx._width + "; border: " + ctx.border + ";");
      ɵɵadvance(3);
      ɵɵproperty("isLoading", ctx.isLoading);
    }
  },
  dependencies: [SDKLoadingComponent],
  encapsulation: 2
});
var SDKGoogleMapComponent = _SDKGoogleMapComponent;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SDKGoogleMapComponent, [{
    type: Component,
    args: [{
      selector: "sdk-google-map",
      template: `<div [style]="'position: relative; height: ' + _height + '; width: ' + _width + '; border: ' + border + ';'">
    <div #map style="height: 100%; width: 100%;"></div>
    <sdk-loading [isLoading]="isLoading"></sdk-loading>
</div>
`
    }]
  }], null, {
    height: [{
      type: Input
    }],
    width: [{
      type: Input
    }],
    latitude: [{
      type: Input
    }],
    longitude: [{
      type: Input
    }],
    location: [{
      type: Input
    }],
    zoom: [{
      type: Input
    }],
    border: [{
      type: Input
    }],
    map: [{
      type: ViewChild,
      args: ["map"]
    }]
  });
})();
var _SDKGoogleMapModule = class _SDKGoogleMapModule {
};
_SDKGoogleMapModule.ɵfac = function SDKGoogleMapModule_Factory(t) {
  return new (t || _SDKGoogleMapModule)();
};
_SDKGoogleMapModule.ɵmod = ɵɵdefineNgModule({
  type: _SDKGoogleMapModule,
  declarations: [SDKGoogleMapComponent],
  imports: [SDKLoadingModule],
  exports: [SDKGoogleMapComponent]
});
_SDKGoogleMapModule.ɵinj = ɵɵdefineInjector({
  imports: [SDKLoadingModule]
});
var SDKGoogleMapModule = _SDKGoogleMapModule;
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SDKGoogleMapModule, [{
    type: NgModule,
    args: [{
      declarations: [SDKGoogleMapComponent],
      imports: [SDKLoadingModule],
      exports: [SDKGoogleMapComponent]
    }]
  }], null, null);
})();
export {
  SDKGoogleMapComponent,
  SDKGoogleMapModule
};
//# sourceMappingURL=sdk-google-map.js.map
