import {
  BasicTracerProvider
} from "./chunk-YUPDH3JR.js";
import {
  SEMATTRS_HTTP_RESPONSE_CONTENT_LENGTH,
  SEMATTRS_HTTP_RESPONSE_CONTENT_LENGTH_UNCOMPRESSED,
  hrTimeToNanoseconds,
  timeInputToHrTime,
  urlMatches
} from "./chunk-FT7YRNA4.js";
import {
  ROOT_CONTEXT
} from "./chunk-UXK5IXEU.js";

// node_modules/@opentelemetry/sdk-trace-web/build/esm/StackContextManager.js
var __read = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2)
    for (var i = 0, l = from.length, ar; i < l; i++) {
      if (ar || !(i in from)) {
        if (!ar)
          ar = Array.prototype.slice.call(from, 0, i);
        ar[i] = from[i];
      }
    }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var StackContextManager = (
  /** @class */
  function() {
    function StackContextManager2() {
      this._enabled = false;
      this._currentContext = ROOT_CONTEXT;
    }
    StackContextManager2.prototype._bindFunction = function(context, target) {
      if (context === void 0) {
        context = ROOT_CONTEXT;
      }
      var manager = this;
      var contextWrapper = function() {
        var _this = this;
        var args = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          args[_i] = arguments[_i];
        }
        return manager.with(context, function() {
          return target.apply(_this, args);
        });
      };
      Object.defineProperty(contextWrapper, "length", {
        enumerable: false,
        configurable: true,
        writable: false,
        value: target.length
      });
      return contextWrapper;
    };
    StackContextManager2.prototype.active = function() {
      return this._currentContext;
    };
    StackContextManager2.prototype.bind = function(context, target) {
      if (context === void 0) {
        context = this.active();
      }
      if (typeof target === "function") {
        return this._bindFunction(context, target);
      }
      return target;
    };
    StackContextManager2.prototype.disable = function() {
      this._currentContext = ROOT_CONTEXT;
      this._enabled = false;
      return this;
    };
    StackContextManager2.prototype.enable = function() {
      if (this._enabled) {
        return this;
      }
      this._enabled = true;
      this._currentContext = ROOT_CONTEXT;
      return this;
    };
    StackContextManager2.prototype.with = function(context, fn, thisArg) {
      var args = [];
      for (var _i = 3; _i < arguments.length; _i++) {
        args[_i - 3] = arguments[_i];
      }
      var previousContext = this._currentContext;
      this._currentContext = context || ROOT_CONTEXT;
      try {
        return fn.call.apply(fn, __spreadArray([thisArg], __read(args), false));
      } finally {
        this._currentContext = previousContext;
      }
    };
    return StackContextManager2;
  }()
);

// node_modules/@opentelemetry/sdk-trace-web/build/esm/WebTracerProvider.js
var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2)
        if (Object.prototype.hasOwnProperty.call(b2, p))
          d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var WebTracerProvider = (
  /** @class */
  function(_super) {
    __extends(WebTracerProvider2, _super);
    function WebTracerProvider2(config) {
      if (config === void 0) {
        config = {};
      }
      var _this = _super.call(this, config) || this;
      if (config.contextManager) {
        throw "contextManager should be defined in register method not in constructor";
      }
      if (config.propagator) {
        throw "propagator should be defined in register method not in constructor";
      }
      return _this;
    }
    WebTracerProvider2.prototype.register = function(config) {
      if (config === void 0) {
        config = {};
      }
      if (config.contextManager === void 0) {
        config.contextManager = new StackContextManager();
      }
      if (config.contextManager) {
        config.contextManager.enable();
      }
      _super.prototype.register.call(this, config);
    };
    return WebTracerProvider2;
  }(BasicTracerProvider)
);

// node_modules/@opentelemetry/sdk-trace-web/build/esm/enums/PerformanceTimingNames.js
var PerformanceTimingNames;
(function(PerformanceTimingNames2) {
  PerformanceTimingNames2["CONNECT_END"] = "connectEnd";
  PerformanceTimingNames2["CONNECT_START"] = "connectStart";
  PerformanceTimingNames2["DECODED_BODY_SIZE"] = "decodedBodySize";
  PerformanceTimingNames2["DOM_COMPLETE"] = "domComplete";
  PerformanceTimingNames2["DOM_CONTENT_LOADED_EVENT_END"] = "domContentLoadedEventEnd";
  PerformanceTimingNames2["DOM_CONTENT_LOADED_EVENT_START"] = "domContentLoadedEventStart";
  PerformanceTimingNames2["DOM_INTERACTIVE"] = "domInteractive";
  PerformanceTimingNames2["DOMAIN_LOOKUP_END"] = "domainLookupEnd";
  PerformanceTimingNames2["DOMAIN_LOOKUP_START"] = "domainLookupStart";
  PerformanceTimingNames2["ENCODED_BODY_SIZE"] = "encodedBodySize";
  PerformanceTimingNames2["FETCH_START"] = "fetchStart";
  PerformanceTimingNames2["LOAD_EVENT_END"] = "loadEventEnd";
  PerformanceTimingNames2["LOAD_EVENT_START"] = "loadEventStart";
  PerformanceTimingNames2["NAVIGATION_START"] = "navigationStart";
  PerformanceTimingNames2["REDIRECT_END"] = "redirectEnd";
  PerformanceTimingNames2["REDIRECT_START"] = "redirectStart";
  PerformanceTimingNames2["REQUEST_START"] = "requestStart";
  PerformanceTimingNames2["RESPONSE_END"] = "responseEnd";
  PerformanceTimingNames2["RESPONSE_START"] = "responseStart";
  PerformanceTimingNames2["SECURE_CONNECTION_START"] = "secureConnectionStart";
  PerformanceTimingNames2["UNLOAD_EVENT_END"] = "unloadEventEnd";
  PerformanceTimingNames2["UNLOAD_EVENT_START"] = "unloadEventStart";
})(PerformanceTimingNames || (PerformanceTimingNames = {}));

// node_modules/@opentelemetry/sdk-trace-web/build/esm/utils.js
var urlNormalizingAnchor;
function getUrlNormalizingAnchor() {
  if (!urlNormalizingAnchor) {
    urlNormalizingAnchor = document.createElement("a");
  }
  return urlNormalizingAnchor;
}
function hasKey(obj, key) {
  return key in obj;
}
function addSpanNetworkEvent(span, performanceName, entries, refPerfName) {
  var perfTime = void 0;
  var refTime = void 0;
  if (hasKey(entries, performanceName) && typeof entries[performanceName] === "number") {
    perfTime = entries[performanceName];
  }
  var refName = refPerfName || PerformanceTimingNames.FETCH_START;
  if (hasKey(entries, refName) && typeof entries[refName] === "number") {
    refTime = entries[refName];
  }
  if (perfTime !== void 0 && refTime !== void 0 && perfTime >= refTime) {
    span.addEvent(performanceName, perfTime);
    return span;
  }
  return void 0;
}
function addSpanNetworkEvents(span, resource) {
  addSpanNetworkEvent(span, PerformanceTimingNames.FETCH_START, resource);
  addSpanNetworkEvent(span, PerformanceTimingNames.DOMAIN_LOOKUP_START, resource);
  addSpanNetworkEvent(span, PerformanceTimingNames.DOMAIN_LOOKUP_END, resource);
  addSpanNetworkEvent(span, PerformanceTimingNames.CONNECT_START, resource);
  if (hasKey(resource, "name") && resource["name"].startsWith("https:")) {
    addSpanNetworkEvent(span, PerformanceTimingNames.SECURE_CONNECTION_START, resource);
  }
  addSpanNetworkEvent(span, PerformanceTimingNames.CONNECT_END, resource);
  addSpanNetworkEvent(span, PerformanceTimingNames.REQUEST_START, resource);
  addSpanNetworkEvent(span, PerformanceTimingNames.RESPONSE_START, resource);
  addSpanNetworkEvent(span, PerformanceTimingNames.RESPONSE_END, resource);
  var encodedLength = resource[PerformanceTimingNames.ENCODED_BODY_SIZE];
  if (encodedLength !== void 0) {
    span.setAttribute(SEMATTRS_HTTP_RESPONSE_CONTENT_LENGTH, encodedLength);
  }
  var decodedLength = resource[PerformanceTimingNames.DECODED_BODY_SIZE];
  if (decodedLength !== void 0 && encodedLength !== decodedLength) {
    span.setAttribute(SEMATTRS_HTTP_RESPONSE_CONTENT_LENGTH_UNCOMPRESSED, decodedLength);
  }
}
function sortResources(filteredResources) {
  return filteredResources.slice().sort(function(a, b) {
    var valueA = a[PerformanceTimingNames.FETCH_START];
    var valueB = b[PerformanceTimingNames.FETCH_START];
    if (valueA > valueB) {
      return 1;
    } else if (valueA < valueB) {
      return -1;
    }
    return 0;
  });
}
function getOrigin() {
  return typeof location !== "undefined" ? location.origin : void 0;
}
function getResource(spanUrl, startTimeHR, endTimeHR, resources, ignoredResources, initiatorType) {
  if (ignoredResources === void 0) {
    ignoredResources = /* @__PURE__ */ new WeakSet();
  }
  var parsedSpanUrl = parseUrl(spanUrl);
  spanUrl = parsedSpanUrl.toString();
  var filteredResources = filterResourcesForSpan(spanUrl, startTimeHR, endTimeHR, resources, ignoredResources, initiatorType);
  if (filteredResources.length === 0) {
    return {
      mainRequest: void 0
    };
  }
  if (filteredResources.length === 1) {
    return {
      mainRequest: filteredResources[0]
    };
  }
  var sorted = sortResources(filteredResources);
  if (parsedSpanUrl.origin !== getOrigin() && sorted.length > 1) {
    var corsPreFlightRequest = sorted[0];
    var mainRequest = findMainRequest(sorted, corsPreFlightRequest[PerformanceTimingNames.RESPONSE_END], endTimeHR);
    var responseEnd = corsPreFlightRequest[PerformanceTimingNames.RESPONSE_END];
    var fetchStart = mainRequest[PerformanceTimingNames.FETCH_START];
    if (fetchStart < responseEnd) {
      mainRequest = corsPreFlightRequest;
      corsPreFlightRequest = void 0;
    }
    return {
      corsPreFlightRequest,
      mainRequest
    };
  } else {
    return {
      mainRequest: filteredResources[0]
    };
  }
}
function findMainRequest(resources, corsPreFlightRequestEndTime, spanEndTimeHR) {
  var spanEndTime = hrTimeToNanoseconds(spanEndTimeHR);
  var minTime = hrTimeToNanoseconds(timeInputToHrTime(corsPreFlightRequestEndTime));
  var mainRequest = resources[1];
  var bestGap;
  var length = resources.length;
  for (var i = 1; i < length; i++) {
    var resource = resources[i];
    var resourceStartTime = hrTimeToNanoseconds(timeInputToHrTime(resource[PerformanceTimingNames.FETCH_START]));
    var resourceEndTime = hrTimeToNanoseconds(timeInputToHrTime(resource[PerformanceTimingNames.RESPONSE_END]));
    var currentGap = spanEndTime - resourceEndTime;
    if (resourceStartTime >= minTime && (!bestGap || currentGap < bestGap)) {
      bestGap = currentGap;
      mainRequest = resource;
    }
  }
  return mainRequest;
}
function filterResourcesForSpan(spanUrl, startTimeHR, endTimeHR, resources, ignoredResources, initiatorType) {
  var startTime = hrTimeToNanoseconds(startTimeHR);
  var endTime = hrTimeToNanoseconds(endTimeHR);
  var filteredResources = resources.filter(function(resource) {
    var resourceStartTime = hrTimeToNanoseconds(timeInputToHrTime(resource[PerformanceTimingNames.FETCH_START]));
    var resourceEndTime = hrTimeToNanoseconds(timeInputToHrTime(resource[PerformanceTimingNames.RESPONSE_END]));
    return resource.initiatorType.toLowerCase() === (initiatorType || "xmlhttprequest") && resource.name === spanUrl && resourceStartTime >= startTime && resourceEndTime <= endTime;
  });
  if (filteredResources.length > 0) {
    filteredResources = filteredResources.filter(function(resource) {
      return !ignoredResources.has(resource);
    });
  }
  return filteredResources;
}
function parseUrl(url) {
  if (typeof URL === "function") {
    return new URL(url, typeof document !== "undefined" ? document.baseURI : typeof location !== "undefined" ? location.href : void 0);
  }
  var element = getUrlNormalizingAnchor();
  element.href = url;
  return element;
}
function normalizeUrl(url) {
  var urlLike = parseUrl(url);
  return urlLike.href;
}
function getElementXPath(target, optimised) {
  if (target.nodeType === Node.DOCUMENT_NODE) {
    return "/";
  }
  var targetValue = getNodeValue(target, optimised);
  if (optimised && targetValue.indexOf("@id") > 0) {
    return targetValue;
  }
  var xpath = "";
  if (target.parentNode) {
    xpath += getElementXPath(target.parentNode, false);
  }
  xpath += targetValue;
  return xpath;
}
function getNodeIndex(target) {
  if (!target.parentNode) {
    return 0;
  }
  var allowedTypes = [target.nodeType];
  if (target.nodeType === Node.CDATA_SECTION_NODE) {
    allowedTypes.push(Node.TEXT_NODE);
  }
  var elements = Array.from(target.parentNode.childNodes);
  elements = elements.filter(function(element) {
    var localName = element.localName;
    return allowedTypes.indexOf(element.nodeType) >= 0 && localName === target.localName;
  });
  if (elements.length >= 1) {
    return elements.indexOf(target) + 1;
  }
  return 0;
}
function getNodeValue(target, optimised) {
  var nodeType = target.nodeType;
  var index = getNodeIndex(target);
  var nodeValue = "";
  if (nodeType === Node.ELEMENT_NODE) {
    var id = target.getAttribute("id");
    if (optimised && id) {
      return '//*[@id="' + id + '"]';
    }
    nodeValue = target.localName;
  } else if (nodeType === Node.TEXT_NODE || nodeType === Node.CDATA_SECTION_NODE) {
    nodeValue = "text()";
  } else if (nodeType === Node.COMMENT_NODE) {
    nodeValue = "comment()";
  } else {
    return "";
  }
  if (nodeValue && index > 1) {
    return "/" + nodeValue + "[" + index + "]";
  }
  return "/" + nodeValue;
}
function shouldPropagateTraceHeaders(spanUrl, propagateTraceHeaderCorsUrls) {
  var propagateTraceHeaderUrls = propagateTraceHeaderCorsUrls || [];
  if (typeof propagateTraceHeaderUrls === "string" || propagateTraceHeaderUrls instanceof RegExp) {
    propagateTraceHeaderUrls = [propagateTraceHeaderUrls];
  }
  var parsedSpanUrl = parseUrl(spanUrl);
  if (parsedSpanUrl.origin === getOrigin()) {
    return true;
  } else {
    return propagateTraceHeaderUrls.some(function(propagateTraceHeaderUrl) {
      return urlMatches(spanUrl, propagateTraceHeaderUrl);
    });
  }
}

export {
  StackContextManager,
  WebTracerProvider,
  PerformanceTimingNames,
  hasKey,
  addSpanNetworkEvent,
  addSpanNetworkEvents,
  sortResources,
  getResource,
  parseUrl,
  normalizeUrl,
  getElementXPath,
  shouldPropagateTraceHeaders
};
//# sourceMappingURL=chunk-VCIPMLAT.js.map
