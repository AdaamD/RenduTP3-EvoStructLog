import {
  InstrumentationBase,
  InstrumentationNodeModuleDefinition,
  InstrumentationNodeModuleFile,
  isWrapped,
  registerInstrumentations,
  safeExecuteInTheMiddle,
  safeExecuteInTheMiddleAsync
} from "./chunk-2S52PPVH.js";
import "./chunk-UXK5IXEU.js";
import "./chunk-ASLTLD6L.js";
export {
  InstrumentationBase,
  InstrumentationNodeModuleDefinition,
  InstrumentationNodeModuleFile,
  isWrapped,
  registerInstrumentations,
  safeExecuteInTheMiddle,
  safeExecuteInTheMiddleAsync
};
//# sourceMappingURL=@opentelemetry_instrumentation.js.map
