ToDo List 
Exercice 1: CLI focntionnelle , il manque ajouter en BD avec BD H2 
