package repository;
@org.springframework.stereotype.Repository
public interface ProductRepository extends org.springframework.data.jpa.repository.JpaRepository<model.Product, java.lang.Long> {}