package repository;
@org.springframework.stereotype.Repository
public interface UserRepository extends org.springframework.data.jpa.repository.JpaRepository<model.User, java.lang.Long> {}