package exception;
@org.springframework.web.bind.annotation.ControllerAdvice
public class GlobalExceptionHandler {
    @org.springframework.web.bind.annotation.ExceptionHandler(exception.ProductNotFoundException.class)
    public org.springframework.http.ResponseEntity<java.lang.String> handleProductNotFoundException(exception.ProductNotFoundException ex) {
        return org.springframework.http.ResponseEntity.status(org.springframework.http.HttpStatus.NOT_FOUND).body(ex.getMessage());
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(exception.ProductAlreadyExistsException.class)
    public org.springframework.http.ResponseEntity<java.lang.String> handleProductAlreadyExistsException(exception.ProductAlreadyExistsException ex) {
        return org.springframework.http.ResponseEntity.status(org.springframework.http.HttpStatus.CONFLICT).body(ex.getMessage());
    }
}