package exception;
public class ProductAlreadyExistsException extends java.lang.RuntimeException {
    public ProductAlreadyExistsException(java.lang.String message) {
        super(message);
    }
}