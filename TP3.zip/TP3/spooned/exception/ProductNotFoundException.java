package exception;
public class ProductNotFoundException extends java.lang.RuntimeException {
    public ProductNotFoundException(java.lang.String message) {
        super(message);
    }
}