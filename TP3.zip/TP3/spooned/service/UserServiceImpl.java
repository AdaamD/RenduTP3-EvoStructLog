package service;
@org.springframework.stereotype.Service
public class UserServiceImpl implements service.UserService {
    @org.springframework.beans.factory.annotation.Autowired
    private repository.UserRepository userRepository;

    @java.lang.Override
    public model.User createUser(model.User user) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: createUser");
        return userRepository.save(user);
    }

    @java.lang.Override
    public model.User getUserById(java.lang.Long id) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getUserById");
        return userRepository.findById(id).orElseThrow(() -> new java.lang.RuntimeException("User not found"));
    }

    @java.lang.Override
    public java.util.List<model.User> getAllUsers() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getAllUsers");
        return userRepository.findAll();
    }

    @java.lang.Override
    public model.User updateUser(java.lang.Long id, model.User userDetails) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: updateUser");
        model.User user = getUserById(id);
        user.setName(userDetails.getName());
        user.setAge(userDetails.getAge());
        user.setEmail(userDetails.getEmail());
        user.setPassword(userDetails.getPassword());
        return userRepository.save(user);
    }

    @java.lang.Override
    public void deleteUser(java.lang.Long id) {
        model.User user = getUserById(id);
        userRepository.delete(user);
    }
}