package service;
public interface UserService {
    model.User createUser(model.User user);

    model.User getUserById(java.lang.Long id);

    java.util.List<model.User> getAllUsers();

    model.User updateUser(java.lang.Long id, model.User user);

    void deleteUser(java.lang.Long id);
}