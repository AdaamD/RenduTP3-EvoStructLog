package service;
@org.springframework.stereotype.Service
public class ProductServiceImpl implements service.ProductService {
    @org.springframework.beans.factory.annotation.Autowired
    private repository.ProductRepository productRepository;

    @java.lang.Override
    public model.Product createProduct(model.Product product) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: createProduct");
        if ((product.getId() != null) && productRepository.existsById(product.getId())) {
            throw new exception.ProductAlreadyExistsException("Product already exists with id: " + product.getId());
        }
        return productRepository.save(product);
    }

    @java.lang.Override
    public model.Product getProductById(java.lang.Long id) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getProductById");
        return productRepository.findById(id).orElseThrow(() -> new exception.ProductNotFoundException("Product not found with id: " + id));
    }

    @java.lang.Override
    public java.util.List<model.Product> getAllProducts() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getAllProducts");
        return productRepository.findAll();
    }

    @java.lang.Override
    public model.Product updateProduct(java.lang.Long id, model.Product productDetails) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: updateProduct");
        model.Product product = getProductById(id);// This will throw ProductNotFoundException if not found

        product.setName(productDetails.getName());
        product.setPrice(productDetails.getPrice());
        product.setExpirationDate(productDetails.getExpirationDate());
        return productRepository.save(product);
    }

    @java.lang.Override
    public void deleteProduct(java.lang.Long id) {
        model.Product product = getProductById(id);// This will throw ProductNotFoundException if not found

        productRepository.delete(product);
    }
}