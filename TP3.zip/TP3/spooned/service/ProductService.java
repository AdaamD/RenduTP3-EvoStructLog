package service;
public interface ProductService {
    model.Product createProduct(model.Product product);

    model.Product getProductById(java.lang.Long id);

    java.util.List<model.Product> getAllProducts();

    model.Product updateProduct(java.lang.Long id, model.Product product);

    void deleteProduct(java.lang.Long id);
}