package logging;
public class ProfileSerializer {
    public void serializeProfiles(java.util.Map<java.lang.String, logging.UserProfile> profiles, java.lang.String outputFilePath) throws java.io.IOException {
        com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
        mapper.writeValue(new java.io.File(outputFilePath), profiles);
    }
}