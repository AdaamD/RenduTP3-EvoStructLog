package logging;
public class UserProfile {
    private java.lang.String userId;

    private int readOperations;

    private int writeOperations;

    private int expensiveProductSearches;

    // Constructor, getters, setters, and increment methods
    public UserProfile(java.lang.String userId) {
        this.userId = userId;
    }

    public void incrementReadOperations() {
        this.readOperations++;
    }

    public void incrementWriteOperations() {
        this.writeOperations++;
    }

    public void incrementExpensiveProductSearches() {
        this.expensiveProductSearches++;
    }

    // Getters and setters...
    public int getReadOperations() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getReadOperations");
        return readOperations;
    }

    public void setReadOperations(int readOperations) {
        this.readOperations = readOperations;
    }

    public java.lang.String getUserId() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getUserId");
        return userId;
    }

    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }

    public int getWriteOperations() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getWriteOperations");
        return writeOperations;
    }

    public void setWriteOperations(int writeOperations) {
        this.writeOperations = writeOperations;
    }

    public int getExpensiveProductSearches() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getExpensiveProductSearches");
        return expensiveProductSearches;
    }

    public void setExpensiveProductSearches(int expensiveProductSearches) {
        this.expensiveProductSearches = expensiveProductSearches;
    }
}