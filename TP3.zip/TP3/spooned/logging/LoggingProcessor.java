package logging;
public class LoggingProcessor {
    public static void main(java.lang.String[] args) {
        spoon.Launcher launcher = new spoon.Launcher();
        launcher.addInputResource("src/main/java");
        launcher.buildModel();
        launcher.getModel().getElements(new spoon.reflect.visitor.filter.TypeFilter<>(spoon.reflect.declaration.CtMethod.class)).forEach(method -> {
            if (method.getBody() != null) {
                spoon.reflect.code.CtCodeSnippetStatement snippet = null;
                if (method.getSimpleName().startsWith("get")) {
                    snippet = launcher.getFactory().Code().createCodeSnippetStatement(("org.slf4j.LoggerFactory.getLogger(getClass()).info(\"Read operation: " + method.getSimpleName()) + "\")");
                } else if (method.getSimpleName().startsWith("create") || method.getSimpleName().startsWith("update")) {
                    snippet = launcher.getFactory().Code().createCodeSnippetStatement(("org.slf4j.LoggerFactory.getLogger(getClass()).info(\"Write operation: " + method.getSimpleName()) + "\")");
                }
                if (snippet != null) {
                    method.getBody().insertBegin(snippet);
                }
            }
        });
        launcher.prettyprint();
    }
}