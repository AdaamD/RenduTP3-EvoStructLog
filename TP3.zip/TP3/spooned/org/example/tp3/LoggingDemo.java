package org.example.tp3;
public class LoggingDemo {
    private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(org.example.tp3.LoggingDemo.class);

    public static void main(java.lang.String[] args) {
        // Niveaux de log
        org.example.tp3.LoggingDemo.logger.trace("C'est un message TRACE");
        org.example.tp3.LoggingDemo.logger.debug("C'est un message DEBUG");
        org.example.tp3.LoggingDemo.logger.info("C'est un message INFO");
        org.example.tp3.LoggingDemo.logger.warn("C'est un message WARN");
        org.example.tp3.LoggingDemo.logger.error("C'est un message ERROR");
        // Logging paramétré
        java.lang.String name = "John";
        int age = 30;
        org.example.tp3.LoggingDemo.logger.info("L'utilisateur {} a {} ans", name, age);
        // Logging d'exceptions
        try {
            throw new java.lang.RuntimeException("Une erreur s'est produite");
        } catch (java.lang.Exception e) {
            org.example.tp3.LoggingDemo.logger.error("Une exception a été attrapée", e);
        }
        // Utilisation de MDC (Mapped Diagnostic Context)
        org.slf4j.MDC.put("userId", "12345");
        org.example.tp3.LoggingDemo.logger.info("Action effectuée par l'utilisateur");
        org.slf4j.MDC.clear();
        // Performance logging
        long startTime = java.lang.System.currentTimeMillis();
        // Simuler une opération longue
        try {
            java.lang.Thread.sleep(1000);
        } catch (java.lang.InterruptedException e) {
            e.printStackTrace();
        }
        long endTime = java.lang.System.currentTimeMillis();
        org.example.tp3.LoggingDemo.logger.info("L'opération a pris {} ms", endTime - startTime);
    }
}