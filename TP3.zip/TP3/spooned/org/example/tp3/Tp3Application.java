package org.example.tp3;
@org.springframework.boot.autoconfigure.SpringBootApplication
@org.springframework.context.annotation.ComponentScan(basePackages = { "org.example.tp3", "service", "repository", "model", "exception" })
@org.springframework.boot.autoconfigure.domain.EntityScan("model")
@org.springframework.data.jpa.repository.config.EnableJpaRepositories("repository")
public class Tp3Application {
    public static void main(java.lang.String[] args) {
        org.springframework.boot.SpringApplication.run(org.example.tp3.Tp3Application.class, args);
        java.lang.System.out.println("\n------ Server Started ------");
    }
}