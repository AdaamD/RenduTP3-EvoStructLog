package org.example.tp3;
@org.springframework.stereotype.Component
public class CliRunner implements org.springframework.boot.CommandLineRunner {
    @org.springframework.beans.factory.annotation.Autowired
    private service.UserService userService;

    @org.springframework.beans.factory.annotation.Autowired
    private service.ProductService productService;

    @java.lang.Override
    public void run(java.lang.String... args) throws java.lang.Exception {
        java.util.Scanner scanner = new java.util.Scanner(java.lang.System.in);
        while (true) {
            java.lang.System.out.println("\n1. Create User");
            java.lang.System.out.println("2. Display Products");
            java.lang.System.out.println("3. Fetch Product by ID");
            java.lang.System.out.println("4. Add New Product");
            java.lang.System.out.println("5. Delete Product");
            java.lang.System.out.println("6. Update Product");
            java.lang.System.out.println("7. Exit");
            java.lang.System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();// Consume newline

            switch (choice) {
                case 1 :
                    createUser(scanner);
                    break;
                case 2 :
                    displayProducts();
                    break;
                case 3 :
                    fetchProductById(scanner);
                    break;
                case 4 :
                    addNewProduct(scanner);
                    break;
                case 5 :
                    deleteProduct(scanner);
                    break;
                case 6 :
                    updateProduct(scanner);
                    break;
                case 7 :
                    java.lang.System.out.println("Exiting...");
                    return;
                default :
                    java.lang.System.out.println("Invalid option. Please try again.");
            }
        } 
    }

    void createUser(java.util.Scanner scanner) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: createUser");
        java.lang.System.out.println("Enter user details:");
        java.lang.System.out.print("Name: ");
        java.lang.String name = scanner.nextLine();
        java.lang.System.out.print("Age: ");
        int age = scanner.nextInt();
        scanner.nextLine();// Consume newline

        java.lang.System.out.print("Email: ");
        java.lang.String email = scanner.nextLine();
        java.lang.System.out.print("Password: ");
        java.lang.String password = scanner.nextLine();
        model.User user = new model.User();
        user.setName(name);
        user.setAge(age);
        user.setEmail(email);
        user.setPassword(password);
        model.User createdUser = userService.createUser(user);
        java.lang.System.out.println("User created successfully with ID: " + createdUser.getId());
    }

    void displayProducts() {
        java.util.List<model.Product> products = productService.getAllProducts();
        if (products.isEmpty()) {
            java.lang.System.out.println("No products found.");
        } else {
            java.lang.System.out.println("Products:");
            for (model.Product product : products) {
                java.lang.System.out.println(product);
            }
        }
    }

    void fetchProductById(java.util.Scanner scanner) {
        java.lang.System.out.print("Enter product ID: ");
        java.lang.Long id = scanner.nextLong();
        scanner.nextLine();// Consume newline

        try {
            model.Product product = productService.getProductById(id);
            java.lang.System.out.println("Product found: " + product);
        } catch (exception.ProductNotFoundException e) {
            java.lang.System.out.println(e.getMessage());
        }
    }

    void addNewProduct(java.util.Scanner scanner) {
        java.lang.System.out.println("Enter product details:");
        java.lang.System.out.print("Name: ");
        java.lang.String name = scanner.nextLine();
        java.lang.System.out.print("Price: ");
        java.math.BigDecimal price = scanner.nextBigDecimal();
        scanner.nextLine();// Consume newline

        java.lang.System.out.print("Expiration date (YYYY-MM-DD): ");
        java.time.LocalDate expirationDate = java.time.LocalDate.parse(scanner.nextLine());
        model.Product product = new model.Product();
        product.setName(name);
        product.setPrice(price);
        product.setExpirationDate(expirationDate);
        try {
            model.Product createdProduct = productService.createProduct(product);
            java.lang.System.out.println("Product created successfully with ID: " + createdProduct.getId());
        } catch (exception.ProductAlreadyExistsException e) {
            java.lang.System.out.println(e.getMessage());
        }
    }

    void deleteProduct(java.util.Scanner scanner) {
        java.lang.System.out.print("Enter product ID to delete: ");
        java.lang.Long id = scanner.nextLong();
        scanner.nextLine();// Consume newline

        try {
            productService.deleteProduct(id);
            java.lang.System.out.println("Product deleted successfully.");
        } catch (exception.ProductNotFoundException e) {
            java.lang.System.out.println(e.getMessage());
        }
    }

    void updateProduct(java.util.Scanner scanner) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: updateProduct");
        java.lang.System.out.print("Enter product ID to update: ");
        java.lang.Long id = scanner.nextLong();
        scanner.nextLine();// Consume newline

        try {
            model.Product existingProduct = productService.getProductById(id);
            java.lang.System.out.println("Enter new details (press enter to keep current value):");
            java.lang.System.out.print(("Name (" + existingProduct.getName()) + "): ");
            java.lang.String name = scanner.nextLine();
            if (!name.isEmpty()) {
                existingProduct.setName(name);
            }
            java.lang.System.out.print(("Price (" + existingProduct.getPrice()) + "): ");
            java.lang.String priceStr = scanner.nextLine();
            if (!priceStr.isEmpty()) {
                existingProduct.setPrice(new java.math.BigDecimal(priceStr));
            }
            java.lang.System.out.print(("Expiration date (" + existingProduct.getExpirationDate()) + "): ");
            java.lang.String dateStr = scanner.nextLine();
            if (!dateStr.isEmpty()) {
                existingProduct.setExpirationDate(java.time.LocalDate.parse(dateStr));
            }
            model.Product updatedProduct = productService.updateProduct(id, existingProduct);
            java.lang.System.out.println("Product updated successfully: " + updatedProduct);
        } catch (exception.ProductNotFoundException e) {
            java.lang.System.out.println(e.getMessage());
        }
    }
}