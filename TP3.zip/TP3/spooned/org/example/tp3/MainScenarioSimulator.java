package org.example.tp3;
@org.springframework.boot.autoconfigure.SpringBootApplication
public class MainScenarioSimulator {
    private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(org.example.tp3.MainScenarioSimulator.class);

    private static final java.util.Random random = new java.util.Random();

    private static service.UserService userService;

    private static service.ProductService productService;

    public static void main(java.lang.String[] args) {
        org.springframework.context.ApplicationContext context = org.springframework.boot.SpringApplication.run(org.example.tp3.MainScenarioSimulator.class, args);
        org.example.tp3.MainScenarioSimulator.userService = context.getBean(service.UserService.class);
        org.example.tp3.MainScenarioSimulator.productService = context.getBean(service.ProductService.class);
        org.example.tp3.MainScenarioSimulator.logger.info("Simulating scenarios...\n");
        org.example.tp3.MainScenarioSimulator.simulateScenarios(5, 20);
        org.example.tp3.MainScenarioSimulator.logger.info("Scenarios simulation completed.\n");
        // Analyse des logs et création des profils utilisateurs
        try {
            java.util.List<lps.LPS> logEntries = lps.LogParser.parseLogs("logs/application.log");
            java.util.Map<java.lang.String, lps.UserProfile> profiles = lps.ProfileBuilder.buildProfiles(logEntries);
            // Affichage des profils
            for (lps.UserProfile profile : profiles.values()) {
                java.lang.System.out.println(profile);
            }
            // Sauvegarde des profils en JSON
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            mapper.writeValue(new java.io.File("user_profiles.json"), profiles);
            org.example.tp3.MainScenarioSimulator.logger.info("User profiles have been saved to user_profiles.json");
        } catch (java.io.IOException e) {
            org.example.tp3.MainScenarioSimulator.logger.error("Error while parsing logs or saving profiles: ", e);
        }
    }

    private static void simulateScenarios(int userCount, int scenariosPerUser) {
        for (int i = 1; i <= userCount; i++) {
            java.lang.String userId = "user" + i;
            org.example.tp3.MainScenarioSimulator.logger.info("   Simulating scenarios for user: {}", userId);
            for (int j = 0; j < scenariosPerUser; j++) {
                org.example.tp3.MainScenarioSimulator.executeRandomScenario(userId);
            }
        }
    }

    private static void executeRandomScenario(java.lang.String userId) {
        int scenario = org.example.tp3.MainScenarioSimulator.random.nextInt(6);
        switch (scenario) {
            case 0 :
                org.example.tp3.MainScenarioSimulator.createUserScenario(userId);
                break;
            case 1 :
                org.example.tp3.MainScenarioSimulator.displayProductsScenario(userId);
                break;
            case 2 :
                org.example.tp3.MainScenarioSimulator.fetchProductByIdScenario(userId);
                break;
            case 3 :
                org.example.tp3.MainScenarioSimulator.addNewProductScenario(userId);
                break;
            case 4 :
                org.example.tp3.MainScenarioSimulator.deleteProductScenario(userId);
                break;
            case 5 :
                org.example.tp3.MainScenarioSimulator.updateProductScenario(userId);
                break;
        }
    }

    private static void createUserScenario(java.lang.String userId) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: createUserScenario");
        org.example.tp3.MainScenarioSimulator.logger.info("User {} is creating a new user", userId);
        java.lang.String name = "Name" + org.example.tp3.MainScenarioSimulator.random.nextInt(100);
        int age = org.example.tp3.MainScenarioSimulator.random.nextInt(80) + 18;
        java.lang.String email = ("email" + org.example.tp3.MainScenarioSimulator.random.nextInt(10000)) + "@example.com";// Augmentation de la plage

        java.lang.String password = "password" + org.example.tp3.MainScenarioSimulator.random.nextInt(1000);
        model.User newUser = new model.User(null, name, age, email, password);
        try {
            model.User createdUser = org.example.tp3.MainScenarioSimulator.userService.createUser(newUser);
            org.example.tp3.MainScenarioSimulator.logger.info("New user created: {}", createdUser.getName());
        } catch (org.springframework.dao.DataIntegrityViolationException e) {
            org.example.tp3.MainScenarioSimulator.logger.warn("Failed to create user with email {}. Email already exists.", email);
            // Vous pouvez choisir de réessayer avec un nouvel email ici si nécessaire
        }
    }

    private static void displayProductsScenario(java.lang.String userId) {
        org.example.tp3.MainScenarioSimulator.logger.info("User {} is displaying all products", userId);
        org.example.tp3.MainScenarioSimulator.productService.getAllProducts().forEach(product -> org.example.tp3.MainScenarioSimulator.logger.info("Product: {}, Price: {}", product.getName(), product.getPrice()));
    }

    private static void fetchProductByIdScenario(java.lang.String userId) {
        long productId = org.example.tp3.MainScenarioSimulator.random.nextLong(100) + 1;
        org.example.tp3.MainScenarioSimulator.logger.info("User {} is fetching product with ID: {}", userId, productId);
        try {
            model.Product product = org.example.tp3.MainScenarioSimulator.productService.getProductById(productId);
            org.example.tp3.MainScenarioSimulator.logger.info("Fetched product: {}", product.getName());
        } catch (java.lang.Exception e) {
            org.example.tp3.MainScenarioSimulator.logger.info("Product with ID {} not found", productId);
        }
    }

    private static void addNewProductScenario(java.lang.String userId) {
        org.example.tp3.MainScenarioSimulator.logger.info("User {} is adding a new product", userId);
        java.lang.String name = "Product" + org.example.tp3.MainScenarioSimulator.random.nextInt(1000);
        java.math.BigDecimal price = java.math.BigDecimal.valueOf(org.example.tp3.MainScenarioSimulator.random.nextDouble() * 1000).setScale(2, java.math.BigDecimal.ROUND_HALF_UP);
        java.time.LocalDate expirationDate = java.time.LocalDate.now().plusDays(org.example.tp3.MainScenarioSimulator.random.nextInt(365));
        model.Product newProduct = new model.Product(null, name, price, expirationDate);
        org.example.tp3.MainScenarioSimulator.productService.createProduct(newProduct);
        org.example.tp3.MainScenarioSimulator.logger.info("New product added: {}", newProduct.getName());
    }

    private static void deleteProductScenario(java.lang.String userId) {
        long productId = org.example.tp3.MainScenarioSimulator.random.nextLong(100) + 1;
        org.example.tp3.MainScenarioSimulator.logger.info("User {} is deleting product with ID: {}", userId, productId);
        try {
            org.example.tp3.MainScenarioSimulator.productService.deleteProduct(productId);
            org.example.tp3.MainScenarioSimulator.logger.info("Product with ID {} deleted", productId);
        } catch (java.lang.Exception e) {
            org.example.tp3.MainScenarioSimulator.logger.info("Product with ID {} not found or could not be deleted", productId);
        }
    }

    private static void updateProductScenario(java.lang.String userId) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: updateProductScenario");
        long productId = org.example.tp3.MainScenarioSimulator.random.nextLong(100) + 1;
        org.example.tp3.MainScenarioSimulator.logger.info("User {} is updating product with ID: {}", userId, productId);
        try {
            model.Product existingProduct = org.example.tp3.MainScenarioSimulator.productService.getProductById(productId);
            java.lang.String updatedName = "UpdatedProduct" + org.example.tp3.MainScenarioSimulator.random.nextInt(1000);
            java.math.BigDecimal updatedPrice = java.math.BigDecimal.valueOf(org.example.tp3.MainScenarioSimulator.random.nextDouble() * 1000).setScale(2, java.math.BigDecimal.ROUND_HALF_UP);
            java.time.LocalDate updatedExpirationDate = java.time.LocalDate.now().plusDays(org.example.tp3.MainScenarioSimulator.random.nextInt(365));
            existingProduct.setName(updatedName);
            existingProduct.setPrice(updatedPrice);
            existingProduct.setExpirationDate(updatedExpirationDate);
            org.example.tp3.MainScenarioSimulator.productService.updateProduct(productId, existingProduct);
            org.example.tp3.MainScenarioSimulator.logger.info("Product updated: {}", existingProduct.getName());
        } catch (java.lang.Exception e) {
            org.example.tp3.MainScenarioSimulator.logger.info("Product with ID {} not found or could not be updated", productId);
        }
    }
}