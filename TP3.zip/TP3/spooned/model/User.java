package model;
import jakarta.persistence.*;
@jakarta.persistence.Entity
@jakarta.persistence.Table(name = "users")
public class User {
    @jakarta.persistence.Id
    @jakarta.persistence.GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)
    private java.lang.Long id;

    @jakarta.persistence.Column(nullable = false)
    private java.lang.String name;

    @jakarta.persistence.Column(nullable = false)
    private int age;

    @jakarta.persistence.Column(nullable = false, unique = true)
    private java.lang.String email;

    @jakarta.persistence.Column(nullable = false)
    private java.lang.String password;

    // Constructeurs, getters, setters, equals, hashCode
    public User(java.lang.Long id, java.lang.String name, int age, java.lang.String email, java.lang.String password) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.password = password;
    }

    public User() {
    }

    public java.lang.Long getId() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getId");
        return id;
    }

    public void setId(java.lang.Long id) {
        this.id = id;
    }

    public java.lang.String getName() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getName");
        return name;
    }

    public void setName(java.lang.String name) {
        this.name = name;
    }

    public int getAge() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getAge");
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public java.lang.String getEmail() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getEmail");
        return email;
    }

    public void setEmail(java.lang.String email) {
        this.email = email;
    }

    public java.lang.String getPassword() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getPassword");
        return password;
    }

    public void setPassword(java.lang.String password) {
        this.password = password;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return ((((((((((((("User{" + "id=") + id) + ", name='") + name) + '\'') + ", age=") + age) + ", email='") + email) + '\'') + ", password='") + password) + '\'') + '}';
    }
}