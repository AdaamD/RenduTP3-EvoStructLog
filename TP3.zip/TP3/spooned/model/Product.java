package model;
import jakarta.persistence.*;
@jakarta.persistence.Entity
@jakarta.persistence.Table(name = "products")
public class Product {
    @jakarta.persistence.Id
    @jakarta.persistence.GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)
    private java.lang.Long id;

    @jakarta.persistence.Column(nullable = false)
    private java.lang.String name;

    @jakarta.persistence.Column(nullable = false)
    private java.math.BigDecimal price;

    @jakarta.persistence.Column(nullable = false)
    private java.time.LocalDate expirationDate;

    // Constructeurs, getters, setters, equals, hashCode
    public Product(java.lang.Long id, java.lang.String name, java.math.BigDecimal price, java.time.LocalDate expirationDate) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.expirationDate = expirationDate;
    }

    public Product() {
    }

    public java.lang.Long getId() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getId");
        return id;
    }

    public void setId(java.lang.Long id) {
        this.id = id;
    }

    public java.lang.String getName() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getName");
        return name;
    }

    public void setName(java.lang.String name) {
        this.name = name;
    }

    public java.math.BigDecimal getPrice() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getPrice");
        return price;
    }

    public void setPrice(java.math.BigDecimal price) {
        this.price = price;
    }

    public java.time.LocalDate getExpirationDate() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getExpirationDate");
        return expirationDate;
    }

    public void setExpirationDate(java.time.LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return ((((((((("Product{" + "id=") + id) + ", name='") + name) + '\'') + ", price=") + price) + ", expirationDate=") + expirationDate) + '}';
    }
}