package lps;
public class UserProfile {
    private java.lang.String userId;

    private int createUserCount;

    private int displayProductsCount;

    private int fetchProductCount;

    private int addProductCount;

    private int deleteProductCount;

    private int updateProductCount;

    public UserProfile(java.lang.String userId) {
        this.userId = userId;
    }

    // Getters
    public java.lang.String getUserId() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getUserId");
        return userId;
    }

    public int getCreateUserCount() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getCreateUserCount");
        return createUserCount;
    }

    public int getDisplayProductsCount() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getDisplayProductsCount");
        return displayProductsCount;
    }

    public int getFetchProductCount() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getFetchProductCount");
        return fetchProductCount;
    }

    public int getAddProductCount() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getAddProductCount");
        return addProductCount;
    }

    public int getDeleteProductCount() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getDeleteProductCount");
        return deleteProductCount;
    }

    public int getUpdateProductCount() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getUpdateProductCount");
        return updateProductCount;
    }

    // Increment methods
    public void incrementCreateUserCount() {
        this.createUserCount++;
    }

    public void incrementDisplayProductsCount() {
        this.displayProductsCount++;
    }

    public void incrementFetchProductCount() {
        this.fetchProductCount++;
    }

    public void incrementAddProductCount() {
        this.addProductCount++;
    }

    public void incrementDeleteProductCount() {
        this.deleteProductCount++;
    }

    public void incrementUpdateProductCount() {
        this.updateProductCount++;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return ((((((((((((((("UserProfile{" + "userId='") + userId) + '\'') + ", createUserCount=") + createUserCount) + ", displayProductsCount=") + displayProductsCount) + ", fetchProductCount=") + fetchProductCount) + ", addProductCount=") + addProductCount) + ", deleteProductCount=") + deleteProductCount) + ", updateProductCount=") + updateProductCount) + '}';
    }
}