package lps;
public class LPSBuilder {
    private LPS lps = new LPS();

    public LPSBuilder withTimestamp(java.time.LocalDateTime timestamp) {
        lps.setTimestamp(timestamp);
        return this;
    }

    public LPSBuilder withEvent(java.lang.String event) {
        lps.setEvent(event);
        return this;
    }

    public LPSBuilder withUser(java.lang.String user) {
        lps.setUser(user);
        return this;
    }

    public LPSBuilder withAction(java.lang.String action) {
        lps.setAction(action);
        return this;
    }

    public LPS build() {
        return lps;
    }
}