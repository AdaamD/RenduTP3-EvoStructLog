package lps;
public class LPS {
    private java.time.LocalDateTime timestamp;

    private java.lang.String event;

    private java.lang.String user;

    private java.lang.String action;

    public LPS() {
    }

    public LPS(java.time.LocalDateTime timestamp, java.lang.String event, java.lang.String user, java.lang.String action) {
        this.timestamp = timestamp;
        this.event = event;
        this.user = user;
        this.action = action;
    }

    // Getters
    public java.time.LocalDateTime getTimestamp() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getTimestamp");
        return timestamp;
    }

    public java.lang.String getEvent() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getEvent");
        return event;
    }

    public java.lang.String getUser() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getUser");
        return user;
    }

    public java.lang.String getAction() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getAction");
        return action;
    }

    // Setters
    public void setTimestamp(java.time.LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public void setEvent(java.lang.String event) {
        this.event = event;
    }

    public void setUser(java.lang.String user) {
        this.user = user;
    }

    public void setAction(java.lang.String action) {
        this.action = action;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return ((((((((((("LPS{" + "timestamp=") + timestamp) + ", event='") + event) + '\'') + ", user='") + user) + '\'') + ", action='") + action) + '\'') + '}';
    }
}