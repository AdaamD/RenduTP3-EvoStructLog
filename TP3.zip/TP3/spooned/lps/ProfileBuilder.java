package lps;
public class ProfileBuilder {
    public static java.util.Map<java.lang.String, lps.UserProfile> buildProfiles(java.util.List<lps.LPS> logEntries) {
        java.util.Map<java.lang.String, lps.UserProfile> profiles = new java.util.HashMap<>();
        for (lps.LPS entry : logEntries) {
            java.lang.String userId = entry.getUser();
            lps.UserProfile profile = profiles.computeIfAbsent(userId, lps.UserProfile::new);
            java.lang.String action = entry.getAction().toLowerCase();
            if (action.contains("creating a new user")) {
                profile.incrementCreateUserCount();
            } else if (action.contains("displaying all products")) {
                profile.incrementDisplayProductsCount();
            } else if (action.contains("fetching product")) {
                profile.incrementFetchProductCount();
            } else if (action.contains("adding a new product")) {
                profile.incrementAddProductCount();
            } else if (action.contains("deleting product")) {
                profile.incrementDeleteProductCount();
            } else if (action.contains("updating product")) {
                profile.incrementUpdateProductCount();
            }
        }
        return profiles;
    }
}