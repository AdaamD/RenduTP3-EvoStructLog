package lps;
public class LogParser {
    private static final java.time.format.DateTimeFormatter DATE_TIME_FORMATTER = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");

    public static java.util.List<lps.LPS> parseLogs(java.lang.String logFilePath) throws java.io.IOException {
        java.util.List<lps.LPS> logEntries = new java.util.ArrayList<>();
        try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(logFilePath))) {
            java.lang.String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("User") && line.contains("is")) {
                    LPS lps = LogParser.parseLine(line);
                    if (lps != null) {
                        logEntries.add(lps);
                    }
                }
            } 
        }
        return logEntries;
    }

    private static lps.LPS parseLine(java.lang.String line) {
        java.lang.String[] parts = line.split(" ", 4);// Sépare en 4 parties max

        if (parts.length >= 4) {
            return new lps.LPSBuilder().withTimestamp(java.time.ZonedDateTime.parse(parts[0], lps.LogParser.DATE_TIME_FORMATTER).toLocalDateTime()).withEvent("USER_ACTION").withUser(parts[1]).withAction(parts[3]).build();
        }
        return null;
    }
}