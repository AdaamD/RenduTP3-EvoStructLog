package controller;
import org.springframework.web.bind.annotation.*;
@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api/products")
public class ProductController {
    @org.springframework.beans.factory.annotation.Autowired
    private service.ProductService productService;

    @org.springframework.web.bind.annotation.PostMapping
    public org.springframework.http.ResponseEntity<model.Product> createProduct(@org.springframework.web.bind.annotation.RequestBody
    model.Product product) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: createProduct");
        return org.springframework.http.ResponseEntity.ok(productService.createProduct(product));
    }

    @org.springframework.web.bind.annotation.GetMapping("/{id}")
    public org.springframework.http.ResponseEntity<model.Product> getProductById(@org.springframework.web.bind.annotation.PathVariable
    java.lang.Long id) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getProductById");
        return org.springframework.http.ResponseEntity.ok(productService.getProductById(id));
    }

    @org.springframework.web.bind.annotation.GetMapping
    public org.springframework.http.ResponseEntity<java.util.List<model.Product>> getAllProducts() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getAllProducts");
        return org.springframework.http.ResponseEntity.ok(productService.getAllProducts());
    }

    @org.springframework.web.bind.annotation.PutMapping("/{id}")
    public org.springframework.http.ResponseEntity<model.Product> updateProduct(@org.springframework.web.bind.annotation.PathVariable
    java.lang.Long id, @org.springframework.web.bind.annotation.RequestBody
    model.Product product) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: updateProduct");
        return org.springframework.http.ResponseEntity.ok(productService.updateProduct(id, product));
    }

    @org.springframework.web.bind.annotation.DeleteMapping("/{id}")
    public org.springframework.http.ResponseEntity<java.lang.Void> deleteProduct(@org.springframework.web.bind.annotation.PathVariable
    java.lang.Long id) {
        productService.deleteProduct(id);
        return org.springframework.http.ResponseEntity.ok().build();
    }
}