package controller;
import org.springframework.web.bind.annotation.*;
@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api/users")
public class UserController {
    @org.springframework.beans.factory.annotation.Autowired
    private service.UserService userService;

    @org.springframework.web.bind.annotation.PostMapping
    public org.springframework.http.ResponseEntity<model.User> createUser(@org.springframework.web.bind.annotation.RequestBody
    model.User user) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: createUser");
        return org.springframework.http.ResponseEntity.ok(userService.createUser(user));
    }

    @org.springframework.web.bind.annotation.GetMapping("/{id}")
    public org.springframework.http.ResponseEntity<model.User> getUserById(@org.springframework.web.bind.annotation.PathVariable
    java.lang.Long id) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getUserById");
        return org.springframework.http.ResponseEntity.ok(userService.getUserById(id));
    }

    @org.springframework.web.bind.annotation.GetMapping
    public org.springframework.http.ResponseEntity<java.util.List<model.User>> getAllUsers() {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Read operation: getAllUsers");
        return org.springframework.http.ResponseEntity.ok(userService.getAllUsers());
    }

    @org.springframework.web.bind.annotation.PutMapping("/{id}")
    public org.springframework.http.ResponseEntity<model.User> updateUser(@org.springframework.web.bind.annotation.PathVariable
    java.lang.Long id, @org.springframework.web.bind.annotation.RequestBody
    model.User user) {
        org.slf4j.LoggerFactory.getLogger(getClass()).info("Write operation: updateUser");
        return org.springframework.http.ResponseEntity.ok(userService.updateUser(id, user));
    }

    @org.springframework.web.bind.annotation.DeleteMapping("/{id}")
    public org.springframework.http.ResponseEntity<java.lang.Void> deleteUser(@org.springframework.web.bind.annotation.PathVariable
    java.lang.Long id) {
        userService.deleteUser(id);
        return org.springframework.http.ResponseEntity.ok().build();
    }
}