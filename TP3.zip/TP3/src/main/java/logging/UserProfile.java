package logging;

public class UserProfile {
    private String userId;
    private int readOperations;
    private int writeOperations;
    private int expensiveProductSearches;

    // Constructor, getters, setters, and increment methods
    public UserProfile(String userId) {
        this.userId = userId;
    }

    public void incrementReadOperations() { this.readOperations++; }
    public void incrementWriteOperations() { this.writeOperations++; }
    public void incrementExpensiveProductSearches() { this.expensiveProductSearches++; }

    // Getters and setters...

    public int getReadOperations() {
        return readOperations;
    }

    public void setReadOperations(int readOperations) {
        this.readOperations = readOperations;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getWriteOperations() {
        return writeOperations;
    }

    public void setWriteOperations(int writeOperations) {
        this.writeOperations = writeOperations;
    }

    public int getExpensiveProductSearches() {
        return expensiveProductSearches;
    }

    public void setExpensiveProductSearches(int expensiveProductSearches) {
        this.expensiveProductSearches = expensiveProductSearches;
    }
}
