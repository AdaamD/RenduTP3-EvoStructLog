package logging;

import com.fasterxml.jackson.databind.ObjectMapper;
import logging.LogAnalyzer;
import logging.UserProfile;

import java.io.File;
import java.io.IOException;
import java.util.Map;

public class MainSpooned {
    public static void main(String[] args) {
        try {
            // Chemin vers le fichier de log
            String logFilePath = "logs/application.log";

            // Analyse des logs
            LogAnalyzer analyzer = new LogAnalyzer();
            Map<String, UserProfile> profiles = analyzer.analyzeLogFile(logFilePath);

            // Catégorisation des utilisateurs
            analyzer.categorizeUsers(profiles);

            // Sérialisation des profils en JSON
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(new File("user_profiles_spoon.json"), profiles);

            System.out.println("Analyse des logs terminée. Les profils utilisateurs ont été sauvegardés dans user_profiles_spoon.json");
        } catch (IOException e) {
            System.err.println("Erreur lors de l'analyse des logs ou de la sauvegarde des profils : " + e.getMessage());
            e.printStackTrace();
        }
    }
}
