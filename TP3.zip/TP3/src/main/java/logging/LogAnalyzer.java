package logging;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class LogAnalyzer {
    public Map<String, UserProfile> analyzeLogFile(String logFilePath) throws IOException {
        Map<String, UserProfile> profiles = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(logFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Extraire l'ID utilisateur (placeholder pour l'exemple)
                String userId = extractUserId(line); // Remplacez par une logique appropriée si nécessaire
                String actionType = extractActionType(line);

                UserProfile profile = profiles.computeIfAbsent(userId, UserProfile::new);

                switch (actionType) {
                    case "READ":
                        profile.incrementReadOperations();
                        break;
                    case "WRITE":
                        profile.incrementWriteOperations();
                        break;
                    case "EXPENSIVE_SEARCH":
                        profile.incrementExpensiveProductSearches();
                        break;
                }
            }
        }

        return profiles;
    }

    private String extractUserId(String logLine) {
        // Placeholder pour l'extraction de l'ID utilisateur
        // Si vous n'avez pas d'ID utilisateur dans les logs, vous pouvez retourner une valeur par défaut
        return "defaultUser"; // Utilisez un ID générique ou ajoutez cette information dans vos logs
    }

    private String extractActionType(String logLine) {
        if (logLine.contains("Product:")) {
            // Extraire le prix du produit pour déterminer s'il s'agit d'une recherche de produit coûteux
            String priceString = logLine.split("Price:")[1].trim();
            double price = Double.parseDouble(priceString);

            if (price > 500) { // Seuil pour considérer comme une recherche de produit coûteux
                return "EXPENSIVE_SEARCH";
            }
            return "READ"; // Considérer que l'affichage d'un produit est une opération de lecture
        }
        return "UNKNOWN"; // Si aucune action reconnue
    }

    public void categorizeUsers(Map<String, UserProfile> profiles) {
        for (Map.Entry<String, UserProfile> entry : profiles.entrySet()) {
            UserProfile profile = entry.getValue();
            if (profile.getReadOperations() > profile.getWriteOperations() &&
                    profile.getReadOperations() > profile.getExpensiveProductSearches()) {
                System.out.println(entry.getKey() + " mostly performs read operations");
            } else if (profile.getWriteOperations() > profile.getReadOperations() &&
                    profile.getWriteOperations() > profile.getExpensiveProductSearches()) {
                System.out.println(entry.getKey() + " mostly performs write operations");
            } else if (profile.getExpensiveProductSearches() > profile.getReadOperations() &&
                    profile.getExpensiveProductSearches() > profile.getWriteOperations()) {
                System.out.println(entry.getKey() + " mostly searches for expensive products");
            } else {
                System.out.println(entry.getKey() + " has mixed usage patterns");
            }
        }
    }
}
