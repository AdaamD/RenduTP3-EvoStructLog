package logging;

import spoon.Launcher;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.visitor.filter.TypeFilter;
import spoon.reflect.code.CtCodeSnippetStatement;

public class LoggingProcessor {
    public static void main(String[] args) {
        Launcher launcher = new Launcher();
        launcher.addInputResource("src/main/java");
        launcher.buildModel();

        launcher.getModel().getElements(new TypeFilter<>(CtMethod.class)).forEach(method -> {
            if (method.getBody() != null) {
                CtCodeSnippetStatement snippet = null;
                if (method.getSimpleName().startsWith("get")) {
                    snippet = launcher.getFactory().Code().createCodeSnippetStatement(
                            "org.slf4j.LoggerFactory.getLogger(getClass()).info(\"Read operation: " + method.getSimpleName() + "\")");
                } else if (method.getSimpleName().startsWith("create") || method.getSimpleName().startsWith("update")) {
                    snippet = launcher.getFactory().Code().createCodeSnippetStatement(
                            "org.slf4j.LoggerFactory.getLogger(getClass()).info(\"Write operation: " + method.getSimpleName() + "\")");
                }
                if (snippet != null) {
                    method.getBody().insertBegin(snippet);
                }
            }
        });

        launcher.prettyprint();
    }
}
